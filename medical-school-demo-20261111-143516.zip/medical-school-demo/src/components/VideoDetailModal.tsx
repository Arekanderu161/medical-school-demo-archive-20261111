import React, { useEffect, useId, useRef, useState } from "react";
import { Check, Copy, Download, Share2, Sparkles, X } from "lucide-react";
import type { VideoGenerationItem } from "../types/telegram";
import { useTelegram } from "../hooks/useTelegram";

interface VideoDetailModalProps {
  generation: VideoGenerationItem | null;
  onClose: () => void;
}

export const VideoDetailModal: React.FC<VideoDetailModalProps> = ({
  generation,
  onClose,
}) => {
  const { tg, hapticImpact, hapticNotification } = useTelegram();
  const dialogRef = useRef<HTMLDialogElement | null>(null);
  const titleId = useId();
  const [copied, setCopied] = useState(false);

  // Sync native <dialog> showModal() and light-dismiss fallback per modern-web-guidance
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;

    if (generation) {
      if (!dialog.open) {
        dialog.showModal();
      }
    } else if (dialog.open) {
      dialog.close();
    }
  }, [generation]);

  // Fallback for browsers without native HTMLDialogElement.prototype.closedBy support
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;

    const handleNativeClose = () => {
      dialog.returnValue = "";
      onClose();
    };

    dialog.addEventListener("close", handleNativeClose);

    let handleBackdropClick: ((event: MouseEvent) => void) | null = null;
    if (
      typeof HTMLDialogElement !== "undefined" &&
      !("closedBy" in HTMLDialogElement.prototype)
    ) {
      handleBackdropClick = (event: MouseEvent) => {
        if (event.target !== dialog) return;
        const rect = dialog.getBoundingClientRect();
        const isDialogContent =
          rect.top <= event.clientY &&
          event.clientY <= rect.top + rect.height &&
          rect.left <= event.clientX &&
          event.clientX <= rect.left + rect.width;
        if (isDialogContent) return;
        dialog.close();
      };
      dialog.addEventListener("click", handleBackdropClick);
    }

    return () => {
      dialog.removeEventListener("close", handleNativeClose);
      if (handleBackdropClick) {
        dialog.removeEventListener("click", handleBackdropClick);
      }
    };
  }, [onClose]);

  // Wire Telegram native BackButton when modal is open, with mandatory offClick cleanup
  useEffect(() => {
    if (!tg?.BackButton || !generation) return;

    const handleBack = () => {
      hapticImpact("light");
      dialogRef.current?.close();
      onClose();
    };

    tg.BackButton.show();
    tg.BackButton.onClick(handleBack);

    return () => {
      tg.BackButton.offClick(handleBack);
      tg.BackButton.hide();
    };
  }, [tg, generation, onClose, hapticImpact]);

  const handleCopyPrompt = async () => {
    if (!generation) return;
    try {
      await navigator.clipboard.writeText(generation.prompt);
      setCopied(true);
      hapticNotification("success");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  const handleShareTelegram = () => {
    if (!generation) return;
    hapticImpact("medium");
    const shareUrl =
      generation.videoUrl ||
      generation.gifUrl ||
      window.location.origin;
    const text = `Check out this AI video I generated with Sora Studio:\n"${generation.prompt}"`;
    const tgShareLink = `https://t.me/share/url?url=${encodeURIComponent(
      shareUrl
    )}&text=${encodeURIComponent(text)}`;

    if (tg?.openTelegramLink) {
      tg.openTelegramLink(tgShareLink);
    } else {
      window.open(tgShareLink, "_blank", "noopener,noreferrer");
    }
  };

  const handleDownloadVideo = () => {
    if (!generation) return;
    hapticImpact("medium");
    const targetUrl = generation.videoUrl || generation.gifUrl;
    if (!targetUrl) return;

    const a = document.createElement("a");
    a.href = targetUrl;
    a.download = `sora-video-${generation._id}.mp4`;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <dialog
      ref={dialogRef}
      className="video-modal-dialog"
      aria-labelledby={titleId}
      {...({ closedby: "any" } as React.DialogHTMLAttributes<HTMLDialogElement>)}
    >
      {generation && (
        <div className="video-modal-content">
          <div className="video-modal-header">
            <div className="video-modal-title-wrap">
              <Sparkles size={16} className="accent-icon" />
              <h2 id={titleId} className="video-modal-title">
                Video Details
              </h2>
            </div>
            <button
              type="button"
              className="icon-close-btn"
              onClick={() => dialogRef.current?.close()}
              aria-label="Close video details"
              autoFocus
            >
              <X size={18} />
            </button>
          </div>

          <div className="video-player-frame">
            {generation.videoUrl ? (
              <video
                key={generation._id}
                src={generation.videoUrl}
                poster={generation.gifUrl ?? undefined}
                controls
                playsInline
                loop
                autoPlay
                className="video-element"
              />
            ) : generation.gifUrl ? (
              <img
                src={generation.gifUrl}
                alt={generation.prompt}
                className="video-element"
              />
            ) : (
              <div className="video-placeholder">Video file unavailable</div>
            )}
          </div>

          <div className="video-prompt-box">
            <div className="video-prompt-header">
              <span className="video-prompt-label">Original Prompt</span>
              <span className="video-date-label">
                {new Date(generation.createdAt).toLocaleString()}
              </span>
            </div>
            <p className="video-prompt-text">{generation.prompt}</p>
          </div>

          <div className="video-actions-grid">
            <button
              type="button"
              className="secondary-btn"
              onClick={handleCopyPrompt}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              <span>{copied ? "Copied!" : "Copy Prompt"}</span>
            </button>

            <button
              type="button"
              className="secondary-btn"
              onClick={handleDownloadVideo}
            >
              <Download size={16} />
              <span>Download MP4</span>
            </button>

            <button
              type="button"
              className="primary-btn full-width-btn"
              onClick={handleShareTelegram}
            >
              <Share2 size={16} />
              <span>Share in Telegram</span>
            </button>
          </div>
        </div>
      )}
    </dialog>
  );
};
