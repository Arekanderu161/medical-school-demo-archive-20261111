import React from "react";
import { Film, History, Settings, Wand2 } from "lucide-react";
import type { AppTab } from "../types/telegram";

interface BottomNavProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab) => void;
  activeGeneratingCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  activeGeneratingCount,
}) => {
  const navItems: Array<{
    id: AppTab;
    label: string;
    icon: React.ReactNode;
    badge?: number;
  }> = [
    {
      id: "history",
      label: "History",
      icon: <History size={19} />,
    },
    {
      id: "generate",
      label: "Generate",
      icon: <Wand2 size={19} />,
      badge: activeGeneratingCount > 0 ? activeGeneratingCount : undefined,
    },
    {
      id: "gallery",
      label: "Gallery",
      icon: <Film size={19} />,
    },
    {
      id: "settings",
      label: "Settings",
      icon: <Settings size={19} />,
    },
  ];

  return (
    <nav className="bottom-nav" aria-label="Primary Navigation">
      {navItems.map((item) => {
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            type="button"
            className={`bottom-nav-item ${isActive ? "active" : ""}`}
            onClick={() => onSelectTab(item.id)}
            aria-current={isActive ? "page" : undefined}
          >
            <div className="bottom-nav-icon-wrap">
              {item.icon}
              {item.badge !== undefined && (
                <span className="nav-badge">{item.badge}</span>
              )}
            </div>
            <span className="bottom-nav-label">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
