import React, { useState } from "react";
import { Bug, ChevronDown, ChevronUp, Play } from "lucide-react";
import { useTelegram } from "../hooks/useTelegram";
import { isLiveConvexConfigured } from "../utils/convexBridge";

export const DebugPanel: React.FC = () => {
  const [expanded, setExpanded] = useState(false);
  const { tg, isMock } = useTelegram();

  if (!import.meta.env.DEV) {
    return null;
  }

  const mainBtnVisible = tg?.MainButton?.isVisible ?? false;
  const mainBtnText = tg?.MainButton?.text || "Generate";

  return (
    <aside className="debug-panel" aria-label="Developer Debug Panel">
      <div className="debug-panel-bar">
        <button
          type="button"
          className="debug-toggle-btn"
          onClick={() => setExpanded((prev) => !prev)}
        >
          <Bug size={13} />
          <span>
            Dev Inspector ({isMock ? "Mock SDK" : "Telegram SDK"} •{" "}
            {isLiveConvexConfigured ? "Convex Cloud" : "Local Store"})
          </span>
          {expanded ? <ChevronDown size={13} /> : <ChevronUp size={13} />}
        </button>

        {mainBtnVisible && (
          <button
            type="button"
            className="debug-mainbtn-simulator"
            disabled={!tg?.MainButton?.isActive}
            onClick={() => window.__triggerTelegramMainButton?.()}
            title="Simulates tapping the native Telegram MainButton in browser dev mode"
          >
            <Play size={11} />
            <span>tg.MainButton: {mainBtnText}</span>
          </button>
        )}
      </div>

      {expanded && (
        <pre className="debug-panel-details">
          {JSON.stringify(
            {
              platform: tg?.platform,
              version: tg?.version,
              colorScheme: tg?.colorScheme,
              viewportHeight: `${tg?.viewportHeight ?? 0}px`,
              initDataPresent: Boolean(tg?.initData),
              user: tg?.initDataUnsafe?.user ?? null,
              mainButton: {
                isVisible: tg?.MainButton?.isVisible,
                isActive: tg?.MainButton?.isActive,
                isProgressVisible: tg?.MainButton?.isProgressVisible,
                text: tg?.MainButton?.text,
              },
              backButtonVisible: tg?.BackButton?.isVisible,
            },
            null,
            2
          )}
        </pre>
      )}
    </aside>
  );
};
