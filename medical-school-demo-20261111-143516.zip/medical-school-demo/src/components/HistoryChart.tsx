import React, { useMemo } from "react";
import type { VideoGenerationItem } from "../types/telegram";

interface HistoryChartProps {
  generations: VideoGenerationItem[];
}

interface DayBucket {
  key: string;
  label: string;
  count: number;
  completedCount: number;
}

export const HistoryChart: React.FC<HistoryChartProps> = ({ generations }) => {
  const buckets = useMemo<DayBucket[]>(() => {
    const days: DayBucket[] = [];
    const now = new Date();

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);

      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(
        2,
        "0"
      )}-${String(d.getDate()).padStart(2, "0")}`;
      const label = d.toLocaleDateString("en-US", { weekday: "short" });

      days.push({
        key,
        label,
        count: 0,
        completedCount: 0,
      });
    }

    const map = new Map(days.map((item) => [item.key, item]));

    for (const gen of generations) {
      const d = new Date(gen.createdAt);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(
        2,
        "0"
      )}-${String(d.getDate()).padStart(2, "0")}`;
      const bucket = map.get(key);
      if (bucket) {
        bucket.count += 1;
        if (gen.status === "completed") {
          bucket.completedCount += 1;
        }
      }
    }

    return days;
  }, [generations]);

  const maxCount = useMemo(
    () => Math.max(3, ...buckets.map((b) => b.count)),
    [buckets]
  );

  const totalWeek = useMemo(
    () => buckets.reduce((acc, b) => acc + b.count, 0),
    [buckets]
  );

  return (
    <section className="card chart-card" aria-label="Generation activity chart">
      <div className="card-header-row">
        <div>
          <h2 className="section-title">Generation Activity</h2>
          <p className="section-subtitle">
            Last 7 days • {totalWeek} video{totalWeek === 1 ? "" : "s"} created
          </p>
        </div>
        <span className="pill-badge">Real-time</span>
      </div>

      <div className="chart-bars-grid" role="img" aria-label="7-day bar chart">
        {buckets.map((bucket) => {
          const heightPct = Math.max(
            10,
            Math.round((bucket.count / maxCount) * 100)
          );
          return (
            <div key={bucket.key} className="chart-bar-column">
              <span className="chart-bar-value">
                {bucket.count > 0 ? bucket.count : ""}
              </span>
              <div className="chart-bar-track">
                <div
                  className={`chart-bar-fill ${
                    bucket.count > 0 ? "active" : "empty"
                  }`}
                  style={{ height: `${heightPct}%` }}
                  title={`${bucket.label}: ${bucket.count} generations`}
                />
              </div>
              <span className="chart-bar-label">{bucket.label}</span>
            </div>
          );
        })}
      </div>
    </section>
  );
};
