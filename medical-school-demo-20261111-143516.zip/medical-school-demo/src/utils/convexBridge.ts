import { useCallback, useEffect, useState } from "react";
import { ConvexReactClient } from "convex/react";
import { api } from "../../convex/_generated/api";
import type { Id } from "../../convex/_generated/dataModel";
import type { UserProfile, VideoGenerationItem } from "../types/telegram";

const LOCAL_GENERATIONS_KEY = "sora_generations_store_v1";

const rawConvexUrl = import.meta.env.VITE_CONVEX_URL as string | undefined;
export const isLiveConvexConfigured = Boolean(
  rawConvexUrl &&
    rawConvexUrl.startsWith("https://") &&
    !rawConvexUrl.includes("your-deployment")
);

export const convexClient = isLiveConvexConfigured
  ? new ConvexReactClient(rawConvexUrl!)
  : null;

function buildAnimatedSvgDataUrl(prompt: string, index: number): string {
  const palettes = [
    ["#0ea5e9", "#6366f1", "#ec4899"],
    ["#10b981", "#06b6d4", "#3b82f6"],
    ["#f59e0b", "#ef4444", "#8b5cf6"],
    ["#14b8a6", "#8b5cf6", "#f43f5e"],
  ];
  const [c1, c2, c3] = palettes[Math.abs(index) % palettes.length];
  const safeLabel = prompt
    .slice(0, 38)
    .replace(/[<>&"']/g, "")
    .trim();

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180" width="320" height="180">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${c1}">
          <animate attributeName="stop-color" values="${c1};${c2};${c3};${c1}" dur="4s" repeatCount="indefinite"/>
        </stop>
        <stop offset="100%" stop-color="${c3}">
          <animate attributeName="stop-color" values="${c3};${c1};${c2};${c3}" dur="4s" repeatCount="indefinite"/>
        </stop>
      </linearGradient>
      <radialGradient id="orb" cx="50%" cy="50%" r="45%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.85"/>
        <stop offset="100%" stop-color="${c2}" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect width="320" height="180" fill="url(#bg)"/>
    <circle cx="160" cy="90" r="62" fill="url(#orb)">
      <animate attributeName="cx" values="95;225;95" dur="3.6s" repeatCount="indefinite"/>
      <animate attributeName="cy" values="65;115;65" dur="2.8s" repeatCount="indefinite"/>
    </circle>
    <rect x="12" y="138" width="296" height="30" rx="8" fill="#090d16" fill-opacity="0.62"/>
    <text x="22" y="157" fill="#f8fafc" font-family="system-ui, sans-serif" font-size="11" font-weight="600">GIF 320p • 8 FPS — ${safeLabel}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const SAMPLE_MP4_URL =
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4";

function getInitialSeedGenerations(userId: string): VideoGenerationItem[] {
  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;

  return [
    {
      _id: "gen_seed_1",
      userId,
      prompt:
        "Cyberpunk Tokyo street in neon rain, cinematic slow-motion reflection in puddles, 35mm anamorphic lens",
      status: "completed",
      videoId: "storage_video_1",
      gifId: "storage_gif_1",
      gifUrl: buildAnimatedSvgDataUrl("Cyberpunk Tokyo neon rain", 0),
      videoUrl: SAMPLE_MP4_URL,
      createdAt: now - 2 * 3600 * 1000,
      updatedAt: now - 2 * 3600 * 1000 + 12000,
    },
    {
      _id: "gen_seed_2",
      userId,
      prompt:
        "Aerial drone flight over bioluminescent ocean waves crashing against volcanic cliffs under aurora borealis",
      status: "completed",
      videoId: "storage_video_2",
      gifId: "storage_gif_2",
      gifUrl: buildAnimatedSvgDataUrl("Bioluminescent ocean aurora", 1),
      videoUrl: SAMPLE_MP4_URL,
      createdAt: now - day - 3 * 3600 * 1000,
      updatedAt: now - day - 3 * 3600 * 1000 + 14000,
    },
    {
      _id: "gen_seed_3",
      userId,
      prompt:
        "Macro time-lapse of a crystal mechanical lotus blooming in golden sunlight with floating dust motes",
      status: "completed",
      videoId: "storage_video_3",
      gifId: "storage_gif_3",
      gifUrl: buildAnimatedSvgDataUrl("Crystal mechanical lotus", 2),
      videoUrl: SAMPLE_MP4_URL,
      createdAt: now - 2 * day - 3600 * 1000,
      updatedAt: now - 2 * day - 3600 * 1000 + 11000,
    },
    {
      _id: "gen_seed_4",
      userId,
      prompt:
        "Astronaut walking through an ancient overgrown glass conservatory on Mars during sunset",
      status: "completed",
      videoId: "storage_video_4",
      gifId: "storage_gif_4",
      gifUrl: buildAnimatedSvgDataUrl("Mars glass conservatory", 3),
      videoUrl: SAMPLE_MP4_URL,
      createdAt: now - 4 * day,
      updatedAt: now - 4 * day + 15000,
    },
  ];
}

const localStoreListeners = new Set<() => void>();

function readLocalGenerations(userId: string): VideoGenerationItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_GENERATIONS_KEY);
    if (!raw) {
      const seeded = getInitialSeedGenerations(userId);
      localStorage.setItem(LOCAL_GENERATIONS_KEY, JSON.stringify(seeded));
      return seeded;
    }
    const parsed = JSON.parse(raw) as VideoGenerationItem[];
    return parsed.sort((a, b) => b.createdAt - a.createdAt);
  } catch {
    return getInitialSeedGenerations(userId);
  }
}

function writeLocalGenerations(items: VideoGenerationItem[]) {
  localStorage.setItem(LOCAL_GENERATIONS_KEY, JSON.stringify(items));
  for (const listener of localStoreListeners) {
    listener();
  }
}

export function useVideoGenerations(token: string | null, userId: string) {
  const [items, setItems] = useState<VideoGenerationItem[]>(() =>
    readLocalGenerations(userId)
  );
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    if (convexClient && token) {
      let active = true;
      setIsLoading(true);
      const watch = convexClient.watchQuery(api.generations.getGenerations, {
        token,
      });
      const unsubscribe = watch.onUpdate(() => {
        if (!active) return;
        const result = watch.localQueryResult();
        if (result) {
          setItems(result as unknown as VideoGenerationItem[]);
          setIsLoading(false);
        }
      });
      return () => {
        active = false;
        unsubscribe();
      };
    }

    const sync = () => {
      setItems(readLocalGenerations(userId));
    };
    sync();
    localStoreListeners.add(sync);
    return () => {
      localStoreListeners.delete(sync);
    };
  }, [token, userId]);

  const startGeneration = useCallback(
    async (prompt: string): Promise<string> => {
      const cleanPrompt = prompt.trim();
      if (cleanPrompt.length < 3) {
        throw new Error("Prompt must be at least 3 characters long");
      }

      if (convexClient && token) {
        const genId = await convexClient.mutation(
          api.generations.startGeneration,
          {
            token,
            prompt: cleanPrompt,
          }
        );
        return String(genId);
      }

      // Local reactive simulation matching PRD Section 5 flow:
      // pending -> generating -> processAndStoreFiles (completed with gifUrl & videoUrl)
      const now = Date.now();
      const newId = `gen_${now}`;
      const current = readLocalGenerations(userId);
      const pendingItem: VideoGenerationItem = {
        _id: newId,
        userId,
        prompt: cleanPrompt,
        status: "pending",
        gifUrl: null,
        videoUrl: null,
        createdAt: now,
        updatedAt: now,
      };

      writeLocalGenerations([pendingItem, ...current]);

      setTimeout(() => {
        const list = readLocalGenerations(userId).map((item) =>
          item._id === newId
            ? {
                ...item,
                status: "generating" as const,
                updatedAt: Date.now(),
              }
            : item
        );
        writeLocalGenerations(list);
      }, 900);

      setTimeout(() => {
        const list = readLocalGenerations(userId).map((item, idx) =>
          item._id === newId
            ? {
                ...item,
                status: "completed" as const,
                videoId: `storage_video_${now}`,
                gifId: `storage_gif_${now}`,
                gifUrl: buildAnimatedSvgDataUrl(cleanPrompt, idx),
                videoUrl: SAMPLE_MP4_URL,
                updatedAt: Date.now(),
              }
            : item
        );
        writeLocalGenerations(list);
      }, 3400);

      return newId;
    },
    [token, userId]
  );

  const retryGeneration = useCallback(
    async (generationId: string): Promise<void> => {
      if (convexClient && token) {
        await convexClient.mutation(api.generations.retryGeneration, {
          token,
          generationId: generationId as Id<"generations">,
        });
        return;
      }

      const list = readLocalGenerations(userId).map((item) =>
        item._id === generationId
          ? {
              ...item,
              status: "generating" as const,
              errorMessage: undefined,
              updatedAt: Date.now(),
            }
          : item
      );
      writeLocalGenerations(list);

      setTimeout(() => {
        const updated = readLocalGenerations(userId).map((item, idx) =>
          item._id === generationId
            ? {
                ...item,
                status: "completed" as const,
                gifUrl: buildAnimatedSvgDataUrl(item.prompt, idx),
                videoUrl: SAMPLE_MP4_URL,
                updatedAt: Date.now(),
              }
            : item
        );
        writeLocalGenerations(updated);
      }, 2400);
    },
    [token, userId]
  );

  const generateDetailedPrompt = useCallback(
    async (simplePrompt: string): Promise<string> => {
      const clean = simplePrompt.trim();
      if (clean.length < 2) {
        throw new Error("Enter a short idea first so AI Help can expand it");
      }

      if (convexClient && token) {
        const res = await convexClient.action(api.ai.generateDetailedPrompt, {
          token,
          prompt: clean,
        });
        return res.prompt;
      }

      await new Promise((r) => setTimeout(r, 650));
      const base = clean.replace(/\.+$/, "");
      return `${base}. Cinematic 4K anamorphic shot, smooth gimbal tracking camera, volumetric golden-hour lighting, physically accurate reflections, shallow depth of field (35mm f/1.4 lens), ultra-detailed textures, 24fps film look.`;
    },
    [token]
  );

  const saveUserProfile = useCallback(
    async (
      updates: { username: string; avatarUrl?: string },
      onLocalUpdate: (u: Partial<UserProfile>) => void
    ) => {
      const cleanedUsername = updates.username.trim();
      if (cleanedUsername.length < 2) {
        throw new Error("Username must be at least 2 characters");
      }

      if (convexClient && token) {
        await convexClient.mutation(api.users.updateUser, {
          token,
          username: cleanedUsername,
          avatarUrl: updates.avatarUrl?.trim() || undefined,
        });
      }

      onLocalUpdate({
        username: cleanedUsername,
        avatarUrl: updates.avatarUrl?.trim() || undefined,
      });
    },
    [token]
  );

  return {
    generations: items,
    isLoading,
    startGeneration,
    retryGeneration,
    generateDetailedPrompt,
    saveUserProfile,
  };
}
