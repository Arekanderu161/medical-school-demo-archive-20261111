import type {
  TelegramBackButton,
  TelegramMainButton,
  TelegramWebApp,
} from "../types/telegram";

const mainButtonListeners = new Set<() => void>();
const backButtonListeners = new Set<() => void>();
const stateChangeListeners = new Set<() => void>();

function notifyMockStateChange() {
  for (const fn of stateChangeListeners) {
    try {
      fn();
    } catch {
      // ignore listener errors
    }
  }
}

export function subscribeMockTelegramState(listener: () => void): () => void {
  stateChangeListeners.add(listener);
  return () => {
    stateChangeListeners.delete(listener);
  };
}

/**
 * Sets up a complete mock `window.Telegram.WebApp` environment when running outside Telegram
 * in a regular desktop browser during development (per `docs/local-development-guide.md`).
 */
export const mockTelegramEnv = (): void => {
  if (typeof window === "undefined") {
    return;
  }

  if (window.Telegram?.WebApp?.initData) {
    return; // Already running inside real Telegram client
  }

  const mockUser = {
    id: 123456789,
    first_name: "Alex",
    last_name: "Creator",
    username: "alex_sora",
    language_code: "en",
    is_premium: true,
  };

  const authDate = Math.floor(Date.now() / 1000);
  const encodedUser = encodeURIComponent(JSON.stringify(mockUser));
  const initData = `query_id=MOCK_QUERY_ID&user=${encodedUser}&auth_date=${authDate}&hash=mock_hash`;

  const mainButton: TelegramMainButton = {
    text: "Generate Video",
    color: "#2ea6ff",
    textColor: "#ffffff",
    isVisible: false,
    isActive: true,
    isProgressVisible: false,
    setText(text: string) {
      this.text = text;
      notifyMockStateChange();
      return this;
    },
    onClick(callback: () => void) {
      mainButtonListeners.add(callback);
      notifyMockStateChange();
      return this;
    },
    offClick(callback: () => void) {
      mainButtonListeners.delete(callback);
      notifyMockStateChange();
      return this;
    },
    show() {
      this.isVisible = true;
      notifyMockStateChange();
      return this;
    },
    hide() {
      this.isVisible = false;
      notifyMockStateChange();
      return this;
    },
    enable() {
      this.isActive = true;
      notifyMockStateChange();
      return this;
    },
    disable() {
      this.isActive = false;
      notifyMockStateChange();
      return this;
    },
    showProgress(leaveActive = false) {
      this.isProgressVisible = true;
      if (!leaveActive) {
        this.isActive = false;
      }
      notifyMockStateChange();
      return this;
    },
    hideProgress() {
      this.isProgressVisible = false;
      this.isActive = true;
      notifyMockStateChange();
      return this;
    },
    setParams(params) {
      if (params.text !== undefined) this.text = params.text;
      if (params.color !== undefined) this.color = params.color;
      if (params.text_color !== undefined) this.textColor = params.text_color;
      if (params.is_active !== undefined) this.isActive = params.is_active;
      if (params.is_visible !== undefined) this.isVisible = params.is_visible;
      notifyMockStateChange();
      return this;
    },
  };

  const backButton: TelegramBackButton = {
    isVisible: false,
    onClick(callback: () => void) {
      backButtonListeners.add(callback);
      notifyMockStateChange();
      return this;
    },
    offClick(callback: () => void) {
      backButtonListeners.delete(callback);
      notifyMockStateChange();
      return this;
    },
    show() {
      this.isVisible = true;
      notifyMockStateChange();
      return this;
    },
    hide() {
      this.isVisible = false;
      notifyMockStateChange();
      return this;
    },
  };

  const prefersLight =
    typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-color-scheme: light)").matches;

  const mockWebApp: TelegramWebApp = {
    initData,
    initDataUnsafe: {
      query_id: "MOCK_QUERY_ID",
      user: mockUser,
      auth_date: authDate,
      hash: "mock_hash",
    },
    version: "7.10",
    platform: "web",
    colorScheme: prefersLight ? "light" : "dark",
    themeParams: prefersLight
      ? {
          bg_color: "#f8fafc",
          secondary_bg_color: "#ffffff",
          text_color: "#0f172a",
          hint_color: "#64748b",
          link_color: "#0284c7",
          button_color: "#0284c7",
          button_text_color: "#ffffff",
        }
      : {
          bg_color: "#0b1120",
          secondary_bg_color: "#151f32",
          text_color: "#f8fafc",
          hint_color: "#94a3b8",
          link_color: "#38bdf8",
          button_color: "#2ea6ff",
          button_text_color: "#ffffff",
        },
    isExpanded: true,
    viewportHeight: window.innerHeight || 820,
    viewportStableHeight: window.innerHeight || 820,
    headerColor: prefersLight ? "#f8fafc" : "#0b1120",
    backgroundColor: prefersLight ? "#f8fafc" : "#0b1120",
    MainButton: mainButton,
    BackButton: backButton,
    HapticFeedback: {
      impactOccurred() {
        return this;
      },
      notificationOccurred() {
        return this;
      },
      selectionChanged() {
        return this;
      },
    },
    ready: () => console.info("[MockTelegram] WebApp.ready()"),
    expand: () => console.info("[MockTelegram] WebApp.expand()"),
    close: () => console.info("[MockTelegram] WebApp.close()"),
    enableClosingConfirmation: () => {},
    disableClosingConfirmation: () => {},
    setHeaderColor: (color: string) => {
      mockWebApp.headerColor = color;
    },
    setBackgroundColor: (color: string) => {
      mockWebApp.backgroundColor = color;
    },
    openLink: (url: string) => {
      window.open(url, "_blank", "noopener,noreferrer");
    },
    openTelegramLink: (url: string) => {
      window.open(url, "_blank", "noopener,noreferrer");
    },
  };

  window.Telegram = {
    WebApp: mockWebApp,
  };

  window.__triggerTelegramMainButton = () => {
    if (!mainButton.isActive || mainButton.isProgressVisible) return;
    for (const cb of Array.from(mainButtonListeners)) {
      cb();
    }
  };

  window.__triggerTelegramBackButton = () => {
    for (const cb of Array.from(backButtonListeners)) {
      cb();
    }
  };

  console.warn("Running with MOCK Telegram WebApp environment (Dev Mode)");
};
