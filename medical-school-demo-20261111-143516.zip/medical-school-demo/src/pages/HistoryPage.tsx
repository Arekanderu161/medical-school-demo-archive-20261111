import React from "react";
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Loader2,
  Play,
  Plus,
  RefreshCw,
} from "lucide-react";
import type { VideoGenerationItem } from "../types/telegram";
import { HistoryChart } from "../components/HistoryChart";

interface HistoryPageProps {
  generations: VideoGenerationItem[];
  onSelectGeneration: (item: VideoGenerationItem) => void;
  onNavigateGenerate: () => void;
  onRetryGeneration: (generationId: string) => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({
  generations,
  onSelectGeneration,
  onNavigateGenerate,
  onRetryGeneration,
}) => {
  const completedCount = generations.filter(
    (g) => g.status === "completed"
  ).length;
  const activeCount = generations.filter(
    (g) => g.status === "pending" || g.status === "generating"
  ).length;

  const recentItems = generations.slice(0, 8);

  return (
    <div className="page-container">
      <div className="stats-summary-grid">
        <div className="stat-tile">
          <span className="stat-value">{generations.length}</span>
          <span className="stat-label">Total Videos</span>
        </div>
        <div className="stat-tile">
          <span className="stat-value">{completedCount}</span>
          <span className="stat-label">Completed GIFs</span>
        </div>
        <div className="stat-tile">
          <span className="stat-value">{activeCount}</span>
          <span className="stat-label">In Queue</span>
        </div>
      </div>

      <HistoryChart generations={generations} />

      <section className="recent-section" aria-label="Recent video generations">
        <div className="section-header-row">
          <h2 className="section-title">Recent Generations</h2>
          <button
            type="button"
            className="text-link-btn"
            onClick={onNavigateGenerate}
          >
            <Plus size={15} />
            <span>New Video</span>
          </button>
        </div>

        {recentItems.length === 0 ? (
          <div className="empty-state-card">
            <p className="empty-state-title">No videos generated yet</p>
            <p className="empty-state-subtitle">
              Create your first AI video with OpenAI Sora and see animated GIF
              previews here in real time.
            </p>
            <button
              type="button"
              className="primary-btn"
              onClick={onNavigateGenerate}
            >
              <Plus size={16} />
              <span>Create First Video</span>
            </button>
          </div>
        ) : (
          <div className="history-list">
            {recentItems.map((item) => (
              <article
                key={item._id}
                className="history-item-card"
                onClick={() => {
                  if (item.status === "completed") {
                    onSelectGeneration(item);
                  }
                }}
              >
                <div className="history-thumb-wrap">
                  {item.gifUrl ? (
                    <img
                      src={item.gifUrl}
                      alt={item.prompt}
                      className="history-gif-thumb"
                      loading="lazy"
                    />
                  ) : (
                    <div className="history-thumb-placeholder">
                      {item.status === "failed" ? (
                        <AlertCircle size={20} />
                      ) : (
                        <Loader2 size={20} className="spin-icon" />
                      )}
                    </div>
                  )}
                  {item.status === "completed" && (
                    <span className="gif-overlay-tag">
                      <Play size={10} /> GIF
                    </span>
                  )}
                </div>

                <div className="history-item-body">
                  <p className="history-item-prompt">{item.prompt}</p>
                  <div className="history-item-meta">
                    <span className={`status-badge status-${item.status}`}>
                      {item.status === "completed" && <CheckCircle2 size={12} />}
                      {item.status === "generating" && (
                        <Loader2 size={12} className="spin-icon" />
                      )}
                      {item.status === "pending" && <Clock size={12} />}
                      {item.status === "failed" && <AlertCircle size={12} />}
                      <span>{item.status}</span>
                    </span>

                    <span className="history-time">
                      {new Date(item.createdAt).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>

                    {item.status === "failed" && (
                      <button
                        type="button"
                        className="retry-inline-btn"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRetryGeneration(item._id);
                        }}
                      >
                        <RefreshCw size={12} />
                        <span>Retry</span>
                      </button>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
