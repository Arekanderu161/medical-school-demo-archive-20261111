import React, { useCallback, useEffect, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Play,
  RefreshCw,
  Sparkles,
  Wand2,
} from "lucide-react";
import type { VideoGenerationItem } from "../types/telegram";
import { useTelegram } from "../hooks/useTelegram";

interface GeneratePageProps {
  generations: VideoGenerationItem[];
  onStartGeneration: (prompt: string) => Promise<string>;
  onEnhancePrompt: (prompt: string) => Promise<string>;
  onRetryGeneration: (generationId: string) => Promise<void>;
  onOpenGenerationModal: (item: VideoGenerationItem) => void;
}

const STYLE_PRESETS = [
  "Cyberpunk neon rain in Tokyo, 35mm anamorphic",
  "Drone flight over bioluminescent arctic glacier",
  "Golden retriever astronaut floating in a sunlit space station",
  "Macro shot of liquid gold swirling around obsidian crystals",
];

export const GeneratePage: React.FC<GeneratePageProps> = ({
  generations,
  onStartGeneration,
  onEnhancePrompt,
  onRetryGeneration,
  onOpenGenerationModal,
}) => {
  const { tg, hapticImpact, hapticNotification } = useTelegram();
  const [prompt, setPrompt] = useState("");
  const [enhancing, setEnhancing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [activeGenId, setActiveGenId] = useState<string | null>(null);
  const [feedbackError, setFeedbackError] = useState<string | null>(null);

  const trackedGeneration =
    generations.find((g) => g._id === activeGenId) ??
    generations.find(
      (g) => g.status === "pending" || g.status === "generating"
    ) ??
    generations[0] ??
    null;

  const isBusyGenerating =
    submitting ||
    trackedGeneration?.status === "pending" ||
    trackedGeneration?.status === "generating";

  const handleGenerate = useCallback(async () => {
    const trimmed = prompt.trim();
    if (trimmed.length < 3) {
      setFeedbackError("Please enter at least 3 characters describing your video.");
      hapticNotification("warning");
      return;
    }

    setFeedbackError(null);
    setSubmitting(true);
    hapticImpact("medium");
    tg?.MainButton?.showProgress();

    try {
      const createdId = await onStartGeneration(trimmed);
      setActiveGenId(createdId);
      setPrompt("");
      hapticNotification("success");
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Failed to start generation";
      setFeedbackError(msg);
      hapticNotification("error");
    } finally {
      setSubmitting(false);
      tg?.MainButton?.hideProgress();
    }
  }, [prompt, onStartGeneration, tg, hapticImpact, hapticNotification]);

  const handleAiHelp = async () => {
    const trimmed = prompt.trim();
    if (trimmed.length < 2) {
      setFeedbackError(
        "Type a short idea first (e.g., 'cat in space'), then tap AI Help."
      );
      hapticNotification("warning");
      return;
    }

    setFeedbackError(null);
    setEnhancing(true);
    hapticImpact("light");

    try {
      const detailed = await onEnhancePrompt(trimmed);
      setPrompt(detailed);
      hapticNotification("success");
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : "Failed to enhance prompt";
      setFeedbackError(msg);
      hapticNotification("error");
    } finally {
      setEnhancing(false);
    }
  };

  // Native Telegram SDK MainButton lifecycle with strict offClick cleanup
  useEffect(() => {
    const mainBtn = tg?.MainButton;
    if (!mainBtn) return;

    mainBtn.setText(
      submitting ? "Submitting to Sora..." : "Generate AI Video"
    );
    mainBtn.show();

    if (prompt.trim().length >= 3 && !submitting) {
      mainBtn.enable();
    } else {
      mainBtn.disable();
    }

    mainBtn.onClick(handleGenerate);

    return () => {
      mainBtn.offClick(handleGenerate);
      mainBtn.hideProgress();
      mainBtn.hide();
    };
  }, [tg, prompt, submitting, handleGenerate]);

  return (
    <div className="page-container">
      <section className="card generate-card">
        <div className="card-header-row">
          <div>
            <h2 className="section-title">Create Your AI Video</h2>
            <p className="section-subtitle">
              Powered by OpenAI Sora API &amp; automatic MP4 → GIF preview pipeline
            </p>
          </div>
        </div>

        <div className="prompt-field-wrapper">
          <div className="prompt-label-row">
            <label htmlFor="sora-prompt-input" className="field-label">
              Video Prompt
            </label>
            <button
              type="button"
              className="ai-help-btn"
              onClick={handleAiHelp}
              disabled={enhancing || submitting}
            >
              {enhancing ? (
                <Loader2 size={14} className="spin-icon" />
              ) : (
                <Sparkles size={14} />
              )}
              <span>{enhancing ? "Expanding..." : "AI Help"}</span>
            </button>
          </div>

          <textarea
            id="sora-prompt-input"
            className="prompt-textarea"
            rows={4}
            placeholder="Describe the scene, subject motion, camera angle, and lighting..."
            value={prompt}
            onChange={(e) => {
              setPrompt(e.target.value);
              if (feedbackError) setFeedbackError(null);
            }}
            maxLength={1200}
          />

          <div className="prompt-footer-row">
            <span className="char-counter">{prompt.length} / 1200</span>
            <span className="hint-text">
              Output: 1280×720 MP4 + 320px 8fps GIF
            </span>
          </div>
        </div>

        <div className="presets-section">
          <span className="presets-title">Try an example idea:</span>
          <div className="presets-chips">
            {STYLE_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                className="preset-chip"
                onClick={() => {
                  setPrompt(preset);
                  setFeedbackError(null);
                }}
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {feedbackError && (
          <div className="alert-banner error-banner" role="alert">
            <AlertTriangle size={16} />
            <span>{feedbackError}</span>
          </div>
        )}

        <button
          type="button"
          className="primary-btn generate-submit-btn"
          onClick={handleGenerate}
          disabled={prompt.trim().length < 3 || submitting}
        >
          {submitting ? (
            <Loader2 size={18} className="spin-icon" />
          ) : (
            <Wand2 size={18} />
          )}
          <span>
            {submitting ? "Starting Sora Generation..." : "Generate Video"}
          </span>
        </button>
      </section>

      {trackedGeneration && (
        <section
          className="card live-status-card"
          aria-live="polite"
          aria-label="Real-time generation status"
        >
          <div className="card-header-row">
            <h3 className="section-title">Real-time Generation Status</h3>
            <span className={`status-badge status-${trackedGeneration.status}`}>
              {(trackedGeneration.status === "pending" ||
                trackedGeneration.status === "generating") && (
                <Loader2 size={12} className="spin-icon" />
              )}
              {trackedGeneration.status === "completed" && (
                <CheckCircle2 size={12} />
              )}
              <span>{trackedGeneration.status.toUpperCase()}</span>
            </span>
          </div>

          <p className="live-status-prompt">{trackedGeneration.prompt}</p>

          <div className="pipeline-steps">
            <div
              className={`pipeline-step ${
                trackedGeneration.status === "pending"
                  ? "current"
                  : "done"
              }`}
            >
              1. Queued in Convex
            </div>
            <div
              className={`pipeline-step ${
                trackedGeneration.status === "generating"
                  ? "current"
                  : trackedGeneration.status === "completed"
                  ? "done"
                  : ""
              }`}
            >
              2. OpenAI Sora Render
            </div>
            <div
              className={`pipeline-step ${
                trackedGeneration.status === "completed" ? "done" : ""
              }`}
            >
              3. MP4 → 320p GIF Stored
            </div>
          </div>

          {trackedGeneration.status === "completed" &&
            trackedGeneration.gifUrl && (
              <div
                className="live-preview-box"
                onClick={() => onOpenGenerationModal(trackedGeneration)}
              >
                <img
                  src={trackedGeneration.gifUrl}
                  alt={trackedGeneration.prompt}
                  className="live-preview-gif"
                />
                <div className="live-preview-caption">
                  <Play size={14} />
                  <span>Tap to watch full MP4, copy prompt, or share</span>
                </div>
              </div>
            )}

          {trackedGeneration.status === "failed" && (
            <div className="failed-box">
              <p className="failed-reason">
                {trackedGeneration.errorMessage ||
                  "Generation failed during processing."}
              </p>
              <button
                type="button"
                className="secondary-btn"
                onClick={() => void onRetryGeneration(trackedGeneration._id)}
              >
                <RefreshCw size={15} />
                <span>Retry Generation</span>
              </button>
            </div>
          )}

          {isBusyGenerating && (
            <p className="realtime-subscription-note">
              Subscribed via Convex real-time query — preview updates
              automatically when complete.
            </p>
          )}
        </section>
      )}
    </div>
  );
};
