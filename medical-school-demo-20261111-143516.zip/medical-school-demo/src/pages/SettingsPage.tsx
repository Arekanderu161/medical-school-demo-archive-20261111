import React, { useEffect, useState } from "react";
import { Check, Save, ShieldCheck, Sparkles, User } from "lucide-react";
import type { UserProfile } from "../types/telegram";
import { useTelegram } from "../hooks/useTelegram";
import { isLiveConvexConfigured } from "../utils/convexBridge";

interface SettingsPageProps {
  user: UserProfile;
  onSaveProfile: (updates: {
    username: string;
    avatarUrl?: string;
  }) => Promise<void>;
}

const AVATAR_PRESETS = [
  "https://api.dicebear.com/9.x/bottts-neutral/svg?seed=SoraNeon",
  "https://api.dicebear.com/9.x/bottts-neutral/svg?seed=CyberDirector",
  "https://api.dicebear.com/9.x/bottts-neutral/svg?seed=NovaCinema",
  "https://api.dicebear.com/9.x/bottts-neutral/svg?seed=AstroLens",
];

export const SettingsPage: React.FC<SettingsPageProps> = ({
  user,
  onSaveProfile,
}) => {
  const { platform, version, colorScheme, hapticNotification } = useTelegram();
  const [username, setUsername] = useState(user.username);
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl ?? "");
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setUsername(user.username);
    setAvatarUrl(user.avatarUrl ?? "");
  }, [user.username, user.avatarUrl]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSavedSuccess(false);
    setSaving(true);

    try {
      await onSaveProfile({
        username,
        avatarUrl: avatarUrl.trim() || undefined,
      });
      setSavedSuccess(true);
      hapticNotification("success");
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update profile");
      hapticNotification("error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="page-container">
      <section className="card profile-summary-card">
        <div className="profile-avatar-row">
          {avatarUrl ? (
            <img
              src={avatarUrl}
              alt={username}
              className="profile-avatar-img"
            />
          ) : (
            <div className="profile-avatar-fallback">
              <User size={26} />
            </div>
          )}

          <div className="profile-identity">
            <div className="profile-name-line">
              <h2 className="profile-display-name">@{username}</h2>
              {user.isPremium && (
                <span className="premium-pill">
                  <Sparkles size={11} /> Premium
                </span>
              )}
            </div>
            <p className="profile-tg-id">Telegram ID: {user.telegramId}</p>
          </div>
        </div>
      </section>

      <form className="card settings-form" onSubmit={handleSubmit}>
        <h3 className="section-title">Profile Management</h3>
        <p className="section-subtitle">
          Synced with your Telegram profile and stored in Convex `users` table
        </p>

        <div className="form-group">
          <label htmlFor="settings-username" className="field-label">
            Display Username
          </label>
          <input
            id="settings-username"
            type="text"
            className="text-input"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            minLength={2}
            maxLength={48}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="settings-avatar" className="field-label">
            Avatar URL (HTTPS)
          </label>
          <input
            id="settings-avatar"
            type="url"
            className="text-input"
            placeholder="https://..."
            value={avatarUrl}
            onChange={(e) => setAvatarUrl(e.target.value)}
          />
        </div>

        <div className="avatar-presets-row">
          <span className="presets-title">Quick avatar presets:</span>
          <div className="avatar-preset-list">
            {AVATAR_PRESETS.map((presetUrl) => (
              <button
                key={presetUrl}
                type="button"
                className={`avatar-preset-btn ${
                  avatarUrl === presetUrl ? "selected" : ""
                }`}
                onClick={() => setAvatarUrl(presetUrl)}
              >
                <img
                  src={presetUrl}
                  alt="Avatar preset"
                  className="avatar-preset-thumb"
                />
              </button>
            ))}
          </div>
        </div>

        {error && <p className="form-error-text">{error}</p>}

        <button type="submit" className="primary-btn" disabled={saving}>
          {savedSuccess ? <Check size={16} /> : <Save size={16} />}
          <span>
            {saving
              ? "Saving to Convex..."
              : savedSuccess
              ? "Saved to Convex!"
              : "Save Profile"}
          </span>
        </button>
      </form>

      <section className="card security-info-card">
        <div className="card-header-row">
          <h3 className="section-title">Telegram &amp; Session Status</h3>
          <ShieldCheck size={18} className="accent-icon" />
        </div>
        <ul className="env-status-list">
          <li>
            <span>Auth Validation</span>
            <strong>HMAC-SHA256 + JWT (30d)</strong>
          </li>
          <li>
            <span>Backend Mode</span>
            <strong>
              {isLiveConvexConfigured ? "Convex Cloud Live" : "Local Dev Store"}
            </strong>
          </li>
          <li>
            <span>Telegram Client</span>
            <strong>
              {platform} (SDK v{version} • {colorScheme})
            </strong>
          </li>
        </ul>
      </section>
    </div>
  );
};
