import React, { useMemo, useState } from "react";
import { Film, Play, Search, Wand2 } from "lucide-react";
import type { VideoGenerationItem } from "../types/telegram";

interface GalleryPageProps {
  generations: VideoGenerationItem[];
  onSelectGeneration: (item: VideoGenerationItem) => void;
  onNavigateGenerate: () => void;
}

export const GalleryPage: React.FC<GalleryPageProps> = ({
  generations,
  onSelectGeneration,
  onNavigateGenerate,
}) => {
  const [searchQuery, setSearchQuery] = useState("");

  const completedVideos = useMemo(() => {
    const list = generations.filter((g) => g.status === "completed");
    if (!searchQuery.trim()) return list;
    const q = searchQuery.toLowerCase();
    return list.filter((g) => g.prompt.toLowerCase().includes(q));
  }, [generations, searchQuery]);

  return (
    <div className="page-container">
      <div className="gallery-header-card card">
        <div className="card-header-row">
          <div>
            <h2 className="section-title">Dynamic GIF Gallery</h2>
            <p className="section-subtitle">
              Looping 320p GIF previews • Tap any card for full MP4 playback
            </p>
          </div>
          <span className="pill-badge">{completedVideos.length} items</span>
        </div>

        <div className="search-input-wrap">
          <Search size={16} className="search-icon" />
          <input
            type="search"
            className="search-input"
            placeholder="Filter gallery by prompt keywords..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            aria-label="Filter gallery by prompt keywords"
          />
        </div>
      </div>

      {completedVideos.length === 0 ? (
        <div className="empty-state-card">
          <Film size={28} className="accent-icon" />
          <p className="empty-state-title">
            {searchQuery
              ? "No matching videos found"
              : "Your gallery is currently empty"}
          </p>
          <p className="empty-state-subtitle">
            {searchQuery
              ? "Try clearing your search filter."
              : "Generated videos are automatically converted to looping GIFs and stored in Convex."}
          </p>
          {!searchQuery && (
            <button
              type="button"
              className="primary-btn"
              onClick={onNavigateGenerate}
            >
              <Wand2 size={16} />
              <span>Generate Video</span>
            </button>
          )}
        </div>
      ) : (
        <div className="gallery-grid">
          {completedVideos.map((item) => (
            <button
              key={item._id}
              type="button"
              className="gallery-card"
              onClick={() => onSelectGeneration(item)}
            >
              <div className="gallery-thumb-container">
                {item.gifUrl ? (
                  <img
                    src={item.gifUrl}
                    alt={item.prompt}
                    className="gallery-gif-image"
                    loading="lazy"
                  />
                ) : (
                  <div className="gallery-placeholder">GIF Preview</div>
                )}
                <span className="gallery-play-badge">
                  <Play size={11} /> MP4
                </span>
              </div>

              <div className="gallery-card-info">
                <p className="gallery-card-prompt">{item.prompt}</p>
                <span className="gallery-card-date">
                  {new Date(item.createdAt).toLocaleDateString()}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
