import { useCallback, useEffect, useState } from "react";
import type { UserProfile } from "../types/telegram";
import { useTelegram } from "./useTelegram";

const AUTH_TOKEN_KEY = "auth_token";
const AUTH_USER_KEY = "auth_user_profile";

function resolveAuthEndpoint(): string | null {
  const explicitApiUrl = import.meta.env.VITE_API_URL as string | undefined;
  const convexSiteUrl = import.meta.env.VITE_CONVEX_SITE_URL as
    | string
    | undefined;

  if (
    explicitApiUrl &&
    !explicitApiUrl.includes("your-deployment") &&
    !explicitApiUrl.includes("your-backend-url")
  ) {
    const base = explicitApiUrl.replace(/\/+$/, "");
    return base.endsWith("/auth/telegram") ? base : `${base}/auth/telegram`;
  }

  if (convexSiteUrl && !convexSiteUrl.includes("your-deployment")) {
    const base = convexSiteUrl.replace(/\/+$/, "");
    return `${base}/api/auth/telegram`;
  }

  return null;
}

export function useAuth() {
  const { tg, initData, user: tgUnsafeUser } = useTelegram();
  const [loading, setLoading] = useState<boolean>(true);
  const [authenticated, setAuthenticated] = useState<boolean>(false);
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [error, setError] = useState<string | null>(null);

  const login = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const currentInitData = tg?.initData || initData;
      if (!currentInitData) {
        throw new Error(
          "Telegram initData is missing. Please open this Mini App inside Telegram."
        );
      }

      const endpoint = resolveAuthEndpoint();

      if (endpoint) {
        const response = await fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "ngrok-skip-browser-warning": "true",
          },
          body: JSON.stringify({ initData: currentInitData }),
        });

        const data = (await response.json()) as {
          success?: boolean;
          token?: string;
          user?: UserProfile;
          error?: string;
          details?: string;
        };

        if (!response.ok || !data.token || !data.user) {
          throw new Error(
            data.details || data.error || `Authentication failed (${response.status})`
          );
        }

        localStorage.setItem(AUTH_TOKEN_KEY, data.token);
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(data.user));
        setToken(data.token);
        setUser(data.user);
        setAuthenticated(true);
        return;
      }

      // Local dev fallback when Convex HTTP endpoint URL is not yet configured in .env
      const storedUserRaw = localStorage.getItem(AUTH_USER_KEY);
      let resolvedProfile: UserProfile;

      if (storedUserRaw) {
        resolvedProfile = JSON.parse(storedUserRaw) as UserProfile;
      } else {
        const fallbackId = String(tgUnsafeUser?.id ?? 123456789);
        resolvedProfile = {
          id: `user_${fallbackId}`,
          telegramId: fallbackId,
          username:
            tgUnsafeUser?.username ||
            tgUnsafeUser?.first_name ||
            "alex_sora",
          firstName: tgUnsafeUser?.first_name ?? "Alex",
          lastName: tgUnsafeUser?.last_name ?? "Creator",
          avatarUrl: tgUnsafeUser?.photo_url,
          languageCode: tgUnsafeUser?.language_code ?? "en",
          isPremium: tgUnsafeUser?.is_premium ?? true,
          createdAt: Date.now(),
        };
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(resolvedProfile));
      }

      const devToken =
        localStorage.getItem(AUTH_TOKEN_KEY) ||
        `dev_jwt_${resolvedProfile.telegramId}_${Date.now()}`;
      localStorage.setItem(AUTH_TOKEN_KEY, devToken);

      setToken(devToken);
      setUser(resolvedProfile);
      setAuthenticated(true);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Authentication failed";
      setError(message);
      setAuthenticated(false);
    } finally {
      setLoading(false);
    }
  }, [tg, initData, tgUnsafeUser]);

  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    setToken(null);
    setUser(null);
    setAuthenticated(false);
  }, []);

  const updateLocalUser = useCallback((updated: Partial<UserProfile>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...updated };
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(next));
      return next;
    });
  }, []);

  useEffect(() => {
    void login();
  }, [login]);

  return {
    loading,
    authenticated,
    token,
    user,
    error,
    login,
    logout,
    updateLocalUser,
    tg,
  };
}
