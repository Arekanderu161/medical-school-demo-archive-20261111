AI Video Generation Telegram Mini App: Product Requirements Document (PRD)

📚 **Related Documentation:**
- [Telegram Mini App Guide](./telegram-mini-app-guide.md) - Complete reference for Telegram Mini Apps architecture, SDK, and authentication
- [Local Development Guide](./local-development-guide.md) - Step-by-step guide for local development with ngrok tunneling

---

1. Introduction

This document outlines the product requirements for a Telegram Mini App that enables users to generate AI videos using OpenAI's Sora API. The application will be built with a React front-end and powered by Convex Cloud for its back-end services. The primary goal is to provide a seamless and intuitive user experience within the Telegram ecosystem, allowing for easy video creation, management, and sharing.

**📖 Implementation Note for AI Developers:**
When implementing features from this PRD, always reference the [Telegram Mini App Guide](./telegram-mini-app-guide.md) for:
- Telegram SDK integration patterns and best practices
- Authentication flow implementation details (initData validation, JWT generation)
- Security requirements and validation algorithms
- UI/UX patterns specific to Telegram Mini Apps
- Backend architecture examples with Express.js and database models

For local development and testing, refer to the [Local Development Guide](./local-development-guide.md) for:
- Setting up ngrok tunneling to test locally in Telegram
- Configuring the Telegram bot with local development URLs
- Debugging tools and monitoring techniques
- Environment configuration for development vs. production

2. User Flow & Authentication

The application will leverage Telegram's native authentication for a frictionless login experience.

2.1. Seamless Login:

Upon opening the Mini App, it will automatically authenticate the user using the Telegram Web SDK.

The front-end will send the initData provided by Telegram to a Convex HTTP endpoint.

The Convex back-end will securely validate this initData to confirm the user's identity.

2.2. Session Management:

Upon successful validation of the Telegram initData, a session will be created for the user in the Convex back-end.

This session will be used to authenticate subsequent requests from the user.

The application will not require traditional email/password login or registration, providing a seamless "logged in" experience as long as the user is within their Telegram session.

**📖 Implementation Reference:**
See [Telegram Mini App Guide - Authentication Section](./telegram-mini-app-guide.md#-процесс-аутентификации) for:
- Complete HMAC-SHA256 validation algorithm (Node.js and Python examples)
- JWT token generation and validation patterns
- Session management best practices
- Security checklist and common pitfalls to avoid

3. Application Components & Features

The application will consist of four main pages, each designed to provide a specific set of functionalities. All UI components, such as buttons, loaders, and navigation elements, will utilize the latest Telegram Web SDK to ensure a native look and feel.

**📖 Implementation Reference:**
See [Telegram Mini App Guide - SDK Section](./telegram-mini-app-guide.md#-telegram-webapp-sdk) for:
- Telegram WebApp SDK initialization and setup
- MainButton, BackButton, and Viewport API usage
- Theme integration (light/dark mode support)
- React integration patterns and custom hooks
- Platform-specific considerations (iOS/Android/Desktop)

**🛠️ Development Setup:**
Before starting implementation, follow the [Local Development Guide](./local-development-guide.md) to:
- Set up ngrok for local HTTPS tunneling
- Configure your Telegram bot for development
- Test your app in real Telegram environment while developing locally

3.1. Main Page: Generation History

Generation History Chart: The main page will feature a visually engaging chart or graph that displays the user's video generation history over time. This will provide a quick overview of their activity.

Recent Generations: Below the chart, a list of the user's most recent video generations will be displayed as animated GIF previews.

Navigation: A persistent navigation bar at the bottom will provide access to the "Generate," "Gallery," and "Settings" pages.

3.2. Generation Window: Create Your AI Video

Prompt Input: A central text input field will allow users to enter their desired prompt for video generation.

AI Prompt Assistant: An "AI Help" button will be available next to the prompt input. Tapping this button will trigger a Convex action that calls a language model (e.g., GPT-4) to expand upon a simple user idea and generate a more detailed and effective prompt for the Sora API.

Generation Request: A "Generate" button, utilizing a native Telegram SDK button, will initiate the video creation process.

This action will trigger a Convex mutation to create a new entry in the generations table with a "pending" status.

Subsequently, a Convex action will be called to send the prompt to the OpenAI Sora API.

Real-time Updates: The UI will provide real-time feedback on the generation status (e.g., "Generating," "Processing"). This will be achieved through Convex's real-time data subscriptions.

3.3. Gallery

Dynamic GIF Previews: The gallery will display all of the user's successfully generated videos. To optimize for performance and user experience, these videos will be dynamically converted to and displayed as looping GIFs.

Video to GIF Conversion: Upon successful video generation, a client-side process will convert the downloaded MP4 video into a GIF for preview purposes.

Video Details: Tapping on a GIF preview will open a detailed view where the user can watch the full video, copy the original prompt, and have options to share or download the video file.

3.4. User Settings

Profile Management: Users will be able to view and update their profile information, which is initially populated from their Telegram profile. This includes their username and avatar.

Telegram Integration: Changes made in the settings will be reflected within the Mini App and stored in the Convex users table.

4. Back-End Architecture (Convex Cloud) - Revised

**📖 Implementation Reference:**
See [Telegram Mini App Guide - Backend Section](./telegram-mini-app-guide.md#️-backend-реализация) for:
- Express.js server setup with CORS configuration
- Auth middleware implementation for protected routes
- User model schema examples (Mongoose/MongoDB)
- Error handling patterns
- Rate limiting configuration

**🔒 Security Requirements:**
Refer to [Telegram Mini App Guide - Security Section](./telegram-mini-app-guide.md#-безопасность) for:
- Security checklist (validation, HTTPS, JWT, rate limiting)
- Protection against common attacks (replay, token theft, brute force)
- Environment variable management
- Best practices for production deployment

4.1. Data Schema:
The Convex database will be structured with the following tables. We will store the generated video and GIF files directly in Convex's S3-backed storage and reference their _storageId in our generations table.

users:

telegramId (string, unique)

username (string)

avatarUrl (string, optional)

createdAt (datetime)

generations:

userId (ID of the user from the users table)

prompt (string)

status (string: "pending", "generating", "completed", "failed")

videoId (v.id("_storage"), optional)

gifId (v.id("_storage"), optional)

createdAt (datetime)

4.2. Convex Functions:

Queries:

getGenerations: A query that retrieves a user's generation history. It will also call storage.getUrl for the gifId of each completed generation to pass the temporary access URL to the front-end for display.[1]

Mutations:

createUser: To create a new user record upon first authentication.

updateUser: To update a user's profile information.

startGeneration: To create a new generation record with a "pending" status and schedule the generation action.

updateGenerationStatus: To update the status of a generation record.

storeFileIds: An internal mutation to store the _storageId for the generated video and GIF in the correct generations document.

Actions:

generateVideo: An action that takes a prompt and a generationId. It will call the OpenAI Sora API to start video generation. After receiving the generated video file, it will fetch the video content.[2]

processAndStoreFiles: An action that takes the fetched video data and the generationId.

It will store the video blob in Convex storage using ctx.storage.store() to get a videoId.[2]

It will then process the video to create a GIF preview.

It will store the generated GIF blob in Convex storage using ctx.storage.store() to get a gifId.

Finally, it will call the storeFileIds internal mutation to save both the videoId and gifId to the corresponding generations document and update the status to "completed".

generateDetailedPrompt: An action that takes a user's simple prompt and uses a large language model to generate a more descriptive prompt.

HTTP Actions:

authenticate: An HTTP endpoint to receive the initData from the Telegram Mini App, validate it, and create a user session.

**📖 Implementation Reference:**
For complete authentication endpoint implementation, see:
- [Telegram Mini App Guide - Express.js Endpoint Example](./telegram-mini-app-guide.md#expressjs-endpoint)
- [Telegram Mini App Guide - initData Validation Algorithm](./telegram-mini-app-guide.md#алгоритм-проверки)

**🛠️ Testing Authentication Locally:**
During development, use [Local Development Guide - Testing Scenarios](./local-development-guide.md#-testing-scenarios) to:
- Test authentication flow in real Telegram app via ngrok
- Debug initData validation issues
- Monitor authentication requests in ngrok inspector
- Verify JWT token generation and storage

5. Asynchronous Video Generation Flow - Revised

This revised flow incorporates fetching the generated media from OpenAI and storing it directly into Convex's file storage.

The user submits a prompt from the React front-end.

A Convex mutation (startGeneration) is called. This creates a new document in the generations table with a status of "pending" and the user's prompt. It also schedules the generateVideo action.

The generateVideo action is invoked. It sends a request to the OpenAI Sora API to begin the video generation.

The action polls the OpenAI API for the status of the generation job.

Once the generation is complete, the generateVideo action retrieves the temporary URL for the generated video file from the OpenAI API.

It then fetches the video content from that URL and gets the video as a blob or buffer.[2]

The action then schedules the processAndStoreFiles action, passing along the raw video data and the generationId.

The processAndStoreFiles action is invoked:

It uploads the video data to Convex using ctx.storage.store(), receiving a videoId.[2]

It processes the video data to create an animated GIF.

It uploads the GIF data to Convex using ctx.storage.store(), receiving a gifId.

It calls an internal mutation (storeFileIds) to update the corresponding document in the generations table with the new videoId, gifId, and sets the status to "completed".

Thanks to Convex's real-time capabilities, the front-end, which is subscribed to a query that calls storage.getUrl() for the GIFs, will automatically update to show the newly generated GIF in the gallery and history

---

## 6. Development Workflow & Guidelines for AI Implementation

### 6.1. Getting Started with Development

**Before Writing Any Code:**

1. **Read the Technical Guides:**
   - Review [Telegram Mini App Guide](./telegram-mini-app-guide.md) completely to understand Telegram Mini Apps architecture
   - Study the authentication flow diagrams and security requirements
   - Understand initData structure and validation process

2. **Setup Local Development Environment:**
   - Follow [Local Development Guide](./local-development-guide.md) to set up ngrok
   - Create a Telegram Bot via @BotFather
   - Configure your local environment for testing in real Telegram app

3. **Understand the Tech Stack:**
   - Frontend: React + Vite + Telegram WebApp SDK
   - Backend: Convex Cloud (or Express.js for reference)
   - External APIs: OpenAI Sora API for video generation
   - Storage: Convex file storage (S3-backed)

### 6.2. Implementation Priority Order

**Phase 1: Foundation (Week 1)**
1. Setup project structure (frontend + backend)
2. Implement Telegram SDK integration and initialization
3. Create authentication flow (initData validation + JWT)
4. Setup basic routing and navigation
5. Implement theme support (light/dark)

**Reference:** [Telegram Mini App Guide - Frontend Implementation](./telegram-mini-app-guide.md#-frontend-реализация)

**Phase 2: Core Features (Week 2-3)**
1. Build user profile management
2. Implement video generation UI and prompt input
3. Create AI prompt enhancement feature
4. Setup Convex database schema
5. Implement video generation action (OpenAI Sora integration)

**Phase 3: Storage & Display (Week 3-4)**
1. Implement file storage in Convex
2. Create video to GIF conversion
3. Build gallery with GIF previews
4. Implement generation history page
5. Add real-time updates for generation status

**Phase 4: Polish & Testing (Week 4-5)**
1. Implement error handling and retry logic
2. Add loading states and progress indicators
3. Optimize performance (lazy loading, code splitting)
4. Cross-platform testing (iOS/Android/Desktop)
5. Security audit and penetration testing

### 6.3. When to Reference Each Documentation

#### Use [Telegram Mini App Guide](./telegram-mini-app-guide.md) when:

| Task | Relevant Section |
|------|-----------------|
| Setting up React app with Telegram SDK | SDK Integration & React Examples |
| Implementing authentication | Authentication Flow & initData Validation |
| Validating initData on backend | Проверка подлинности initData (Node.js/Python examples) |
| Creating protected API routes | Backend Implementation & Auth Middleware |
| Implementing MainButton/BackButton | Основные методы и свойства |
| Applying Telegram theme colors | Работа с темами Telegram |
| Handling security concerns | Безопасность section |
| Debugging common issues | Частые проблемы и решения |
| Creating user authentication hook | React Hook для авторизации |
| Setting up Express.js server | Полный Express.js сервер |

#### Use [Local Development Guide](./local-development-guide.md) when:

| Task | Relevant Section |
|------|-----------------|
| First time setting up development | Initial Setup |
| Installing and configuring ngrok | Prerequisites & ngrok Installation |
| Creating Telegram bot for testing | Step 3: Create Telegram Bot |
| Starting local dev server with tunnel | Development Workflow |
| Testing in Telegram app | Testing in Telegram |
| Debugging "Invalid hash" errors | Troubleshooting - Invalid hash |
| Fixing CORS issues | Troubleshooting - CORS Error |
| Setting up environment variables | Environment Configuration |
| Monitoring API requests | Monitoring Traffic with ngrok |
| Creating debug tools | Debug Mode Setup |
| Testing on multiple platforms | Testing Scenarios |

### 6.4. Code Quality & Best Practices

**Frontend Best Practices:**
- Always call `tg.ready()` and `tg.expand()` on initialization
- Use Telegram theme colors for consistent UI
- Handle loading states for all async operations
- Implement proper error boundaries
- Support both light and dark themes
- Test on actual Telegram clients (iOS/Android/Desktop)

**Backend Best Practices:**
- Always validate initData hash on backend (NEVER trust frontend)
- Check auth_date timestamp (must be < 24 hours old)
- Use environment variables for all secrets
- Implement rate limiting on authentication endpoint
- Log all authentication attempts
- Use HTTPS for all communications
- Validate and sanitize all user inputs

**Security Checklist (from Guide):**
- ✅ Validate hash on backend
- ✅ Check auth_date timestamp
- ✅ Store BOT_TOKEN in environment variables
- ✅ Use HTTPS for all requests
- ✅ Generate JWT with expiration
- ✅ Validate JWT on protected endpoints
- ✅ Implement rate limiting
- ✅ Log authentication attempts

### 6.5. Testing Strategy

**Local Testing Workflow:**
1. Start dev server: `npm run dev`
2. Start ngrok tunnel: `ngrok http 3000`
3. Update bot URL in @BotFather with ngrok URL
4. Open bot in Telegram and test feature
5. Monitor requests in ngrok inspector (http://127.0.0.1:4040)
6. Check browser DevTools for console errors
7. Verify API calls succeed with correct data

**Multi-Platform Testing:**
- Test on iOS Telegram
- Test on Android Telegram
- Test on Desktop Telegram (Windows/Mac)
- Test on Telegram Web
- Verify theme adaptation (light/dark mode)
- Check viewport handling on different screen sizes

**Test Each Feature:**
- User authentication flow
- Profile loading and display
- Prompt input and validation
- AI prompt enhancement
- Video generation request
- Real-time status updates
- GIF preview display
- Video playback in gallery
- Error handling and retry logic

### 6.6. Environment Configuration

**Required Environment Variables:**

**Frontend (.env):**
```bash
VITE_API_URL=https://your-backend-url.com/api
VITE_BOT_USERNAME=your_bot_username
```

**Backend (.env):**
```bash
# Telegram
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# JWT
JWT_SECRET=your-super-secret-jwt-key-minimum-32-characters
JWT_EXPIRATION=30d

# Convex
CONVEX_URL=https://your-deployment.convex.cloud
CONVEX_DEPLOY_KEY=your-deploy-key

# OpenAI
OPENAI_API_KEY=sk-proj-your-api-key

# Server
PORT=3001
NODE_ENV=development
FRONTEND_URL=https://your-ngrok-url.ngrok-free.app
```

### 6.7. Common Pitfalls to Avoid

❌ **Don't:**
- Trust `initDataUnsafe` without validating hash on backend
- Hardcode BOT_TOKEN or secrets in code
- Skip the `auth_date` timestamp validation
- Use HTTP instead of HTTPS
- Forget to call `tg.ready()` and `tg.expand()`
- Ignore CORS configuration
- Deploy without testing on all Telegram platforms
- Store sensitive data in localStorage without encryption
- Skip error handling for API calls
- Forget to show loading states

✅ **Do:**
- Always validate initData hash on backend using BOT_TOKEN
- Use environment variables for all secrets
- Implement proper error boundaries and error handling
- Test in real Telegram app using ngrok during development
- Apply Telegram theme colors for native look
- Implement rate limiting on authentication endpoints
- Log authentication attempts for security monitoring
- Support both light and dark themes
- Test on iOS, Android, Desktop, and Web versions
- Use the ngrok inspector to debug API calls

### 6.8. Debugging Checklist

When something doesn't work:

**Authentication Issues:**
- [ ] Check if `tg.initData` is available (console.log it)
- [ ] Verify BOT_TOKEN is correct in backend .env
- [ ] Ensure auth_date is recent (< 24 hours)
- [ ] Check hash validation algorithm is correct
- [ ] Verify CORS is configured for ngrok URL
- [ ] Check ngrok inspector for request/response
- [ ] Verify JWT is being stored in localStorage
- [ ] Check if Authorization header is sent with token

**UI Issues:**
- [ ] Verify Telegram SDK script is loaded
- [ ] Check if `tg.ready()` is called
- [ ] Verify theme colors are applied
- [ ] Check viewport height and expansion
- [ ] Test on actual Telegram client (not browser)
- [ ] Verify MainButton/BackButton configuration
- [ ] Check console for JavaScript errors

**API Issues:**
- [ ] Check network tab for failed requests
- [ ] Verify API URL is correct in .env
- [ ] Check CORS configuration on backend
- [ ] Verify JWT token is valid
- [ ] Check ngrok tunnel is running
- [ ] Verify backend server is running
- [ ] Check backend logs for errors

### 6.9. Resources Quick Reference

**Official Documentation:**
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Telegram WebApps](https://core.telegram.org/bots/webapps)
- [Convex Documentation](https://docs.convex.dev/)
- [OpenAI Sora API](https://platform.openai.com/docs/)

**Project Documentation:**
- [This PRD](./RPD.md) - Product requirements and feature specifications
- [Telegram Mini App Guide](./telegram-mini-app-guide.md) - Technical implementation guide
- [Local Development Guide](./local-development-guide.md) - Development and testing setup

**Tools:**
- [ngrok](https://ngrok.com) - HTTPS tunneling for local development
- [@BotFather](https://t.me/BotFather) - Create and manage Telegram bots

---

## Summary for AI Developers

This PRD provides the product requirements. For implementation:

1. **Start Here:** Read this PRD to understand WHAT to build
2. **Then Read:** [Telegram Mini App Guide](./telegram-mini-app-guide.md) to understand HOW to build it
3. **Setup Development:** Follow [Local Development Guide](./local-development-guide.md) to test while building

Always reference the guides when implementing authentication, SDK integration, or testing locally. Follow the security checklist and best practices to ensure a robust, secure application.

**Ready to start development? Begin with Phase 1 of the Implementation Priority Order above!**