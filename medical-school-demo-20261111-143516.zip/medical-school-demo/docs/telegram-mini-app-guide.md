# ✈️ Telegram Mini Apps: Полное руководство

**Архитектура, SDK, аутентификация и интеграция с backend**

---

## 📖 Введение в Telegram Mini Apps

**Telegram Mini Apps** (ранее Web Apps) — это веб-приложения, которые запускаются внутри Telegram и имеют доступ к данным пользователя, платформенным функциям и нативному UI.

### Ключевые особенности

- 🚀 **Нативная интеграция** - Полный доступ к Telegram API без необходимости установки отдельного приложения
- 🔐 **Встроенная аутентификация** - Автоматическая авторизация через Telegram без паролей и регистраций
- 💰 **Платежи** - Интегрированные платежи через Telegram Payments
- 🎨 **Адаптивный дизайн** - Автоматическая адаптация под темы Telegram (светлая/темная)
- 📱 **Кросс-платформенность** - Работает на iOS, Android, Desktop и Web версиях Telegram
- ⚡ **Мгновенный запуск** - Открываются мгновенно, без загрузки из App Store

---

## 🏗️ Архитектура Telegram Mini Apps

### Общая архитектура системы

```mermaid
graph TB
    subgraph "Telegram Client"
        A[Пользователь] --> B[Telegram App]
        B --> C[Mini App Container]
        C --> D[WebView/Browser]
    end
    
    subgraph "Your Mini App"
        D --> E[Frontend<br/>React/Vue/Vanilla]
        E --> F[Telegram WebApp SDK]
        F --> G[initData<br/>user, hash, auth_date]
    end
    
    subgraph "Your Backend"
        G --> H[API Endpoint<br/>/auth/telegram]
        H --> I{Validate<br/>initData}
        I -->|Valid| J[Extract User Data]
        I -->|Invalid| K[Reject 401]
        J --> L{User exists?}
        L -->|Yes| M[Find User in DB]
        L -->|No| N[Create New User]
        M --> O[Generate JWT Token]
        N --> O
        O --> P[Return Auth Response]
    end
    
    P --> E
    E --> Q[Store Token<br/>Make Authenticated Requests]
    
    style B fill:#229ED9
    style F fill:#229ED9
    style O fill:#10b981
    style K fill:#ef4444
```

### Компоненты взаимодействия

```mermaid
sequenceDiagram
    participant U as Пользователь
    participant T as Telegram
    participant MA as Mini App
    participant SDK as WebApp SDK
    participant BE as Backend API
    participant DB as Database
    
    U->>T: Открывает Mini App
    T->>MA: Загружает приложение в WebView
    MA->>SDK: Инициализация Telegram.WebApp
    SDK->>MA: Возвращает initData + user info
    
    Note over MA,SDK: initData содержит:<br/>user, hash, auth_date, query_id
    
    MA->>BE: POST /auth/telegram<br/>{initData}
    
    BE->>BE: Проверяет hash<br/>используя bot token
    
    alt Hash валиден
        BE->>DB: Ищет пользователя по telegram_id
        
        alt Пользователь существует
            DB->>BE: Возвращает user данные
        else Новый пользователь
            BE->>DB: Создает нового пользователя
            DB->>BE: Возвращает созданного user
        end
        
        BE->>BE: Генерирует JWT token
        BE->>MA: {token, user}<br/>200 OK
        MA->>MA: Сохраняет token в localStorage
        MA->>U: Показывает приложение
    else Hash невалиден
        BE->>MA: {error}<br/>401 Unauthorized
        MA->>U: Показывает ошибку
    end
```

---

## 🧩 Компоненты Telegram Mini App

### Диаграмма компонентов

```mermaid
graph LR
    subgraph "Frontend Layer"
        A[HTML/CSS/JS] --> B[UI Framework<br/>React/Vue/Angular]
        B --> C[Telegram WebApp SDK]
    end
    
    subgraph "Telegram Layer"
        C --> D[telegram.WebApp API]
        D --> E[initData]
        D --> F[Theme Parameters]
        D --> G[Main Button]
        D --> H[Back Button]
        D --> I[Viewport]
    end
    
    subgraph "Backend Layer"
        E --> J[Auth Endpoint]
        J --> K[Validation Logic]
        K --> L[User Management]
        L --> M[JWT Generation]
    end
    
    subgraph "Data Layer"
        M --> N[(Database)]
        N --> O[Users Table]
        N --> P[Sessions Table]
    end
    
    style C fill:#229ED9
    style D fill:#229ED9
    style M fill:#10b981
```

### Основные компоненты

| Компонент | Назначение | Расположение |
|-----------|-----------|--------------|
| **WebApp SDK** | Основной JavaScript SDK для взаимодействия с Telegram | Frontend |
| **initData** | Зашифрованные данные пользователя от Telegram | Frontend → Backend |
| **Bot Token** | Секретный ключ для проверки подлинности данных | Backend (env) |
| **Validation Logic** | Проверка hash и временных меток | Backend |
| **JWT Token** | Токен для последующих авторизованных запросов | Backend → Frontend |

---

## 📱 Telegram WebApp SDK

Telegram WebApp SDK предоставляется через глобальный объект `window.Telegram.WebApp` и доступен после загрузки скрипта.

### Подключение SDK

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Telegram Mini App</title>
    
    <!-- Telegram WebApp SDK -->
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
</head>
<body>
    <div id="app"></div>
    
    <script>
        // SDK доступен через window.Telegram.WebApp
        const tg = window.Telegram.WebApp;
        
        // Инициализация
        tg.ready();
        
        console.log('User:', tg.initDataUnsafe.user);
        console.log('InitData:', tg.initData);
    </script>
</body>
</html>
```

> **⚠️ Важно:** SDK загружается синхронно и блокирует рендеринг. Размещайте скрипт в `<head>` для гарантированной доступности при инициализации приложения.

---

## Инициализация приложения

### Базовая инициализация

```javascript
// Получаем доступ к Telegram WebApp
const tg = window.Telegram.WebApp;

// Инициализация (обязательно!)
tg.ready();

// Разворачиваем приложение на весь экран
tg.expand();

// Включаем режим закрытия через свайп
tg.enableClosingConfirmation();

// Устанавливаем цвет хедера
tg.setHeaderColor('bg_color'); // или '#RRGGBB'

// Устанавливаем цвет фона
tg.setBackgroundColor('bg_color');

console.log('Platform:', tg.platform); // 'ios', 'android', 'web', etc.
console.log('Version:', tg.version);   // '6.0'
console.log('Color Scheme:', tg.colorScheme); // 'light' or 'dark'
```

### Инициализация в React

```jsx
import { useEffect, useState } from 'react';

function App() {
    const [tg] = useState(window.Telegram.WebApp);
    const [user, setUser] = useState(null);

    useEffect(() => {
        // Инициализация при монтировании
        tg.ready();
        tg.expand();
        
        // Получаем данные пользователя
        const userData = tg.initDataUnsafe?.user;
        if (userData) {
            setUser(userData);
        }
        
        // Применяем тему Telegram
        document.body.style.backgroundColor = tg.backgroundColor;
        
        // Настройка MainButton
        tg.MainButton.setText('Продолжить');
        tg.MainButton.show();
        tg.MainButton.onClick(() => {
            console.log('MainButton clicked!');
        });
        
        // Cleanup
        return () => {
            tg.MainButton.hide();
        };
    }, [tg]);

    return (
        <div className="app" style={{
            color: tg.themeParams.text_color,
            backgroundColor: tg.themeParams.bg_color
        }}>
            <h1>Привет, {user?.first_name || 'Пользователь'}!</h1>
            <p>Telegram ID: {user?.id}</p>
        </div>
    );
}

export default App;
```

---

## Основные методы и свойства

### Свойства WebApp

| Свойство/Метод | Тип | Описание |
|----------------|-----|----------|
| `initData` | string | Строка с данными инициализации (для отправки на backend) |
| `initDataUnsafe` | object | Распарсенные данные (НЕБЕЗОПАСНО для авторизации) |
| `version` | string | Версия WebApp API |
| `platform` | string | Платформа: 'ios', 'android', 'web', etc. |
| `colorScheme` | string | 'light' или 'dark' |
| `themeParams` | object | Цвета темы Telegram |
| `isExpanded` | boolean | Развернуто ли приложение на весь экран |
| `viewportHeight` | number | Высота видимой области |
| `ready()` | method | Сообщает Telegram что приложение готово |
| `expand()` | method | Разворачивает на весь экран |
| `close()` | method | Закрывает приложение |
| `sendData(data)` | method | Отправляет данные боту |

### MainButton API

| Метод | Описание |
|-------|----------|
| `MainButton.setText(text)` | Устанавливает текст кнопки |
| `MainButton.show()` | Показывает кнопку |
| `MainButton.hide()` | Скрывает кнопку |
| `MainButton.onClick(callback)` | Обработчик клика |
| `MainButton.showProgress()` | Показывает индикатор загрузки |
| `MainButton.hideProgress()` | Скрывает индикатор загрузки |

---

## Работа с темами Telegram

### Применение темы

```javascript
const tg = window.Telegram.WebApp;

// Получаем параметры темы
const theme = tg.themeParams;

// Применяем CSS переменные
document.documentElement.style.setProperty('--tg-theme-bg-color', theme.bg_color);
document.documentElement.style.setProperty('--tg-theme-text-color', theme.text_color);
document.documentElement.style.setProperty('--tg-theme-hint-color', theme.hint_color);
document.documentElement.style.setProperty('--tg-theme-link-color', theme.link_color);
document.documentElement.style.setProperty('--tg-theme-button-color', theme.button_color);
document.documentElement.style.setProperty('--tg-theme-button-text-color', theme.button_text_color);

// Или используем напрямую
document.body.style.backgroundColor = theme.bg_color;
document.body.style.color = theme.text_color;
```

### Доступные цвета темы

| Параметр | Описание |
|----------|----------|
| `bg_color` | Основной цвет фона |
| `text_color` | Цвет текста |
| `hint_color` | Цвет подсказок/вторичного текста |
| `link_color` | Цвет ссылок |
| `button_color` | Цвет кнопок |
| `button_text_color` | Цвет текста на кнопках |
| `secondary_bg_color` | Вторичный цвет фона |

---

## 🔐 Процесс аутентификации

### Полный flow аутентификации

```mermaid
flowchart TD
    Start([Пользователь открывает Mini App]) --> Init[Telegram загружает WebApp]
    Init --> SDK[SDK инициализируется<br/>window.Telegram.WebApp]
    SDK --> GetData[Получаем initData<br/>tg.initData]
    
    GetData --> CheckData{initData<br/>существует?}
    CheckData -->|Нет| Error1[Ошибка: запущено не в Telegram]
    CheckData -->|Да| SendToBackend[POST /auth/telegram<br/>{initData: '...'}]
    
    SendToBackend --> Backend{Backend:<br/>Проверка hash}
    
    Backend -->|Invalid| Error2[401 Unauthorized<br/>Невалидный hash]
    Backend -->|Valid| ParseData[Парсим initData<br/>Извлекаем user данные]
    
    ParseData --> CheckUser{Пользователь<br/>существует?}
    
    CheckUser -->|Да| LoadUser[SELECT * FROM users<br/>WHERE telegram_id = ?]
    CheckUser -->|Нет| CreateUser[INSERT INTO users<br/>telegram_id, username, etc.]
    
    LoadUser --> GenToken[Генерируем JWT token<br/>payload: {userId, telegramId}]
    CreateUser --> GenToken
    
    GenToken --> Response[Response:<br/>{token, user}]
    Response --> SaveToken[Frontend сохраняет token<br/>localStorage.setItem]
    
    SaveToken --> AuthRequests[Все запросы с токеном<br/>Authorization: Bearer token]
    AuthRequests --> AppReady([Приложение готово!])
    
    Error1 --> End([Показать ошибку])
    Error2 --> End
    
    style SDK fill:#229ED9
    style GenToken fill:#10b981
    style Error1 fill:#ef4444
    style Error2 fill:#ef4444
    style AppReady fill:#10b981
```

---

## Структура initData

`initData` — это строка параметров, подписанная Telegram, которая содержит информацию о пользователе и контексте запуска приложения.

### Формат initData (URL-encoded string)

```
query_id=AAHdF6IQAAAAAN0XohDhrOrc
user=%7B%22id%22%3A279058397%2C%22first_name%22%3A%22Ivan%22%2C%22last_name%22%3A%22Petrov%22%2C%22username%22%3A%22ivanpetrov%22%2C%22language_code%22%3A%22ru%22%7D
auth_date=1702234567
hash=5a3f2b1c8d9e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a
```

### Распарсенная структура (initDataUnsafe)

```javascript
{
  "query_id": "AAHdF6IQAAAAAN0XohDhrOrc",
  "user": {
    "id": 279058397,
    "first_name": "Ivan",
    "last_name": "Petrov",
    "username": "ivanpetrov",
    "language_code": "ru",
    "is_premium": true,
    "allows_write_to_pm": true
  },
  "auth_date": 1702234567,
  "hash": "5a3f2b1c8d9e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a"
}
```

### Параметры initData

| Параметр | Тип | Описание |
|----------|-----|----------|
| `query_id` | string | Уникальный ID запроса (опционально) |
| `user` | object | Данные пользователя Telegram |
| `receiver` | object | Данные получателя (в inline режиме) |
| `chat` | object | Данные чата (если запущено из чата) |
| `chat_type` | string | 'sender', 'private', 'group', 'supergroup', 'channel' |
| `chat_instance` | string | ID экземпляра чата |
| `start_param` | string | Параметр из deep link |
| `auth_date` | number | Unix timestamp авторизации |
| `hash` | string | HMAC-SHA256 подпись данных |

### Структура объекта User

```javascript
{
  "id": 279058397,              // Telegram User ID (уникальный!)
  "first_name": "Ivan",         // Имя
  "last_name": "Petrov",        // Фамилия (опционально)
  "username": "ivanpetrov",     // Username (опционально)
  "language_code": "ru",        // Код языка
  "is_premium": true,           // Premium аккаунт?
  "allows_write_to_pm": true,   // Разрешает ли боту писать в ЛС
  "photo_url": "https://..."    // URL аватара (опционально)
}
```

---

## Проверка подлинности initData

> **🔒 КРИТИЧЕСКИ ВАЖНО:** Никогда не доверяйте `initDataUnsafe` на frontend! Любой пользователь может подделать эти данные. Всегда проверяйте `hash` на backend.

### Алгоритм проверки

```mermaid
flowchart LR
    A[initData от клиента] --> B[Парсим параметры]
    B --> C[Извлекаем hash]
    B --> D[Создаем data_check_string]
    
    D --> E[Сортируем параметры<br/>кроме hash]
    E --> F[Объединяем через \n]
    
    F --> G[Создаем secret_key<br/>HMAC-SHA256<br/>data: 'WebAppData'<br/>key: BOT_TOKEN]
    
    G --> H[Вычисляем hash<br/>HMAC-SHA256<br/>data: data_check_string<br/>key: secret_key]
    
    H --> I{hash ==<br/>received_hash?}
    
    I -->|Да| J[Проверка auth_date]
    I -->|Нет| K[❌ ОТКЛОНИТЬ]
    
    J --> L{auth_date<br/>< now - 86400?}
    
    L -->|Да| M[✅ ВАЛИДНО]
    L -->|Нет| N[❌ УСТАРЕЛО]
    
    style M fill:#10b981
    style K fill:#ef4444
    style N fill:#ef4444
```

### Алгоритм проверки (Step-by-step)

1. **Парсинг:** Распарсить initData URL-encoded строку
2. **Извлечение hash:** Сохранить значение параметра `hash`
3. **Формирование data_check_string:**
   - Удалить параметр `hash` из данных
   - Отсортировать остальные параметры по ключу
   - Создать строку вида: `key1=value1\nkey2=value2\n...`
4. **Создание secret_key:**
   ```
   secret_key = HMAC-SHA256("WebAppData", BOT_TOKEN)
   ```
5. **Вычисление hash:**
   ```
   calculated_hash = HMAC-SHA256(data_check_string, secret_key)
   ```
6. **Сравнение:** `calculated_hash === received_hash`
7. **Проверка времени:** `auth_date > now() - 86400` (24 часа)

### Пример реализации (Node.js)

```javascript
const crypto = require('crypto');

function validateTelegramWebAppData(initData, botToken) {
    // 1. Парсим initData
    const urlParams = new URLSearchParams(initData);
    const data = Object.fromEntries(urlParams.entries());
    
    // 2. Извлекаем hash
    const receivedHash = data.hash;
    delete data.hash;
    
    // 3. Проверяем наличие обязательных полей
    if (!receivedHash || !data.auth_date) {
        return { valid: false, error: 'Missing required fields' };
    }
    
    // 4. Проверяем время (не старше 24 часов)
    const authDate = parseInt(data.auth_date);
    const currentTime = Math.floor(Date.now() / 1000);
    
    if (currentTime - authDate > 86400) {
        return { valid: false, error: 'Data is too old' };
    }
    
    // 5. Формируем data_check_string
    const dataCheckString = Object.keys(data)
        .sort()
        .map(key => `${key}=${data[key]}`)
        .join('\n');
    
    // 6. Создаем secret_key
    const secretKey = crypto
        .createHmac('sha256', 'WebAppData')
        .update(botToken)
        .digest();
    
    // 7. Вычисляем hash
    const calculatedHash = crypto
        .createHmac('sha256', secretKey)
        .update(dataCheckString)
        .digest('hex');
    
    // 8. Сравниваем
    if (calculatedHash !== receivedHash) {
        return { valid: false, error: 'Invalid hash' };
    }
    
    // 9. Парсим user данные
    const user = JSON.parse(data.user);
    
    return {
        valid: true,
        user: {
            id: user.id,
            first_name: user.first_name,
            last_name: user.last_name,
            username: user.username,
            language_code: user.language_code,
            is_premium: user.is_premium
        }
    };
}

module.exports = validateTelegramWebAppData;
```

### Пример для Python

```python
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qs

def validate_telegram_webapp_data(init_data: str, bot_token: str) -> dict:
    """
    Валидация initData от Telegram WebApp
    """
    # 1. Парсим initData
    try:
        data = dict(parse_qs(init_data, strict_parsing=True))
        data = {k: v[0] for k, v in data.items()}
    except Exception:
        return {"valid": False, "error": "Invalid init data format"}
    
    # 2. Извлекаем hash
    received_hash = data.pop("hash", None)
    if not received_hash:
        return {"valid": False, "error": "Hash not found"}
    
    # 3. Проверяем auth_date
    auth_date = data.get("auth_date")
    if not auth_date:
        return {"valid": False, "error": "auth_date not found"}
    
    try:
        auth_date = int(auth_date)
    except ValueError:
        return {"valid": False, "error": "Invalid auth_date"}
    
    # Проверка времени (не старше 24 часов)
    if time.time() - auth_date > 86400:
        return {"valid": False, "error": "Data is too old"}
    
    # 4. Создаем data_check_string
    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(data.items())
    )
    
    # 5. Создаем secret_key
    secret_key = hmac.new(
        key=b"WebAppData",
        msg=bot_token.encode(),
        digestmod=hashlib.sha256
    ).digest()
    
    # 6. Вычисляем hash
    calculated_hash = hmac.new(
        key=secret_key,
        msg=data_check_string.encode(),
        digestmod=hashlib.sha256
    ).hexdigest()
    
    # 7. Сравниваем
    if calculated_hash != received_hash:
        return {"valid": False, "error": "Invalid hash"}
    
    # 8. Парсим user
    try:
        user = json.loads(data.get("user", "{}"))
    except json.JSONDecodeError:
        return {"valid": False, "error": "Invalid user data"}
    
    return {
        "valid": True,
        "user": {
            "id": user.get("id"),
            "first_name": user.get("first_name"),
            "last_name": user.get("last_name"),
            "username": user.get("username"),
            "language_code": user.get("language_code"),
            "is_premium": user.get("is_premium", False)
        }
    }
```

---

## Backend авторизация

### Процесс на backend

```mermaid
sequenceDiagram
    participant FE as Frontend
    participant API as API Endpoint
    participant Val as Validator
    participant DB as Database
    participant JWT as JWT Service
    
    FE->>API: POST /auth/telegram<br/>{initData}
    
    API->>Val: validateInitData(initData, BOT_TOKEN)
    
    Val->>Val: Parse initData
    Val->>Val: Extract & check hash
    Val->>Val: Check auth_date
    Val->>Val: Calculate hash
    Val->>Val: Compare hashes
    
    alt Invalid
        Val-->>API: {valid: false, error}
        API-->>FE: 401 Unauthorized
    else Valid
        Val-->>API: {valid: true, user}
        
        API->>DB: SELECT * FROM users<br/>WHERE telegram_id = user.id
        
        alt User exists
            DB-->>API: User data
        else New user
            API->>DB: INSERT INTO users<br/>(telegram_id, username, ...)
            DB-->>API: New user data
        end
        
        API->>JWT: generateToken(user)
        JWT-->>API: JWT token
        
        API-->>FE: 200 OK<br/>{token, user}
    end
```

### Express.js endpoint

```javascript
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const validateTelegramWebAppData = require('../utils/validateInitData');
const User = require('../models/User');

router.post('/auth/telegram', async (req, res) => {
    try {
        const { initData } = req.body;
        
        // 1. Валидация initData
        const validation = validateTelegramWebAppData(
            initData,
            process.env.BOT_TOKEN
        );
        
        if (!validation.valid) {
            return res.status(401).json({
                error: 'Invalid authentication data',
                details: validation.error
            });
        }
        
        const telegramUser = validation.user;
        
        // 2. Поиск или создание пользователя
        let user = await User.findOne({
            telegram_id: telegramUser.id
        });
        
        if (!user) {
            // Создаем нового пользователя
            user = await User.create({
                telegram_id: telegramUser.id,
                username: telegramUser.username,
                first_name: telegramUser.first_name,
                last_name: telegramUser.last_name,
                language_code: telegramUser.language_code,
                is_premium: telegramUser.is_premium || false
            });
        } else {
            // Обновляем данные существующего
            user.username = telegramUser.username;
            user.first_name = telegramUser.first_name;
            user.last_name = telegramUser.last_name;
            user.last_login = new Date();
            await user.save();
        }
        
        // 3. Генерация JWT токена
        const token = jwt.sign(
            {
                userId: user._id,
                telegramId: user.telegram_id
            },
            process.env.JWT_SECRET,
            { expiresIn: '30d' }
        );
        
        // 4. Возвращаем результат
        res.json({
            success: true,
            token,
            user: {
                id: user._id,
                telegram_id: user.telegram_id,
                username: user.username,
                first_name: user.first_name,
                last_name: user.last_name,
                is_premium: user.is_premium
            }
        });
        
    } catch (error) {
        console.error('Auth error:', error);
        res.status(500).json({
            error: 'Internal server error'
        });
    }
});

module.exports = router;
```

### Модель пользователя (Mongoose)

```javascript
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    telegram_id: {
        type: Number,
        required: true,
        unique: true,
        index: true
    },
    username: {
        type: String,
        default: null
    },
    first_name: {
        type: String,
        required: true
    },
    last_name: {
        type: String,
        default: null
    },
    language_code: {
        type: String,
        default: 'en'
    },
    is_premium: {
        type: Boolean,
        default: false
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    last_login: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('User', userSchema);
```

---

## Полный User Flow

```mermaid
graph TB
    Start([Пользователь нажимает на бота]) --> OpenApp[Telegram открывает Mini App]
    OpenApp --> LoadSDK[Загрузка Telegram SDK]
    LoadSDK --> InitSDK[tg.ready<br/>tg.expand]
    
    InitSDK --> GetInitData[const initData = tg.initData]
    
    GetInitData --> ShowUI[Показать UI<br/>с индикатором загрузки]
    
    ShowUI --> SendAuth[fetch '/api/auth/telegram'<br/>body: {initData}]
    
    SendAuth --> BackendValidate{Backend:<br/>Валидация}
    
    BackendValidate -->|Invalid| ShowError[Показать ошибку<br/>Попробовать снова]
    BackendValidate -->|Valid| CheckDB{Пользователь<br/>в DB?}
    
    CheckDB -->|Нет| CreateInDB[Создать пользователя<br/>в базе данных]
    CheckDB -->|Да| LoadFromDB[Загрузить пользователя<br/>из базы данных]
    
    CreateInDB --> GenJWT[Сгенерировать<br/>JWT token]
    LoadFromDB --> GenJWT
    
    GenJWT --> ReturnToken[Вернуть<br/>{token, user}]
    
    ReturnToken --> SaveToken[localStorage.setItem<br/>'auth_token', token]
    
    SaveToken --> SetupAPI[Настроить API client<br/>с токеном]
    
    SetupAPI --> LoadUserData[Загрузить данные<br/>пользователя]
    
    LoadUserData --> ShowApp[Показать приложение]
    
    ShowApp --> UserInteracts[Пользователь<br/>взаимодействует]
    
    UserInteracts --> MakeRequests[Делаем запросы<br/>с Bearer token]
    
    MakeRequests --> BackendAuth{Backend:<br/>Проверка JWT}
    
    BackendAuth -->|Valid| ProcessRequest[Обработка запроса]
    BackendAuth -->|Invalid| Logout[Logout<br/>Повторная авторизация]
    
    ProcessRequest --> UserInteracts
    
    ShowError --> End([Конец])
    Logout --> SendAuth
    
    style InitSDK fill:#229ED9
    style GenJWT fill:#10b981
    style ShowApp fill:#10b981
    style ShowError fill:#ef4444
```

---

## 💻 Frontend реализация

### React приложение с аутентификацией

```jsx
import { useEffect, useState } from 'react';
import axios from 'axios';

const API_URL = 'https://your-api.com';

function App() {
    const [tg] = useState(window.Telegram.WebApp);
    const [loading, setLoading] = useState(true);
    const [authenticated, setAuthenticated] = useState(false);
    const [user, setUser] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Инициализация Telegram WebApp
        tg.ready();
        tg.expand();
        
        // Применяем тему
        document.body.style.backgroundColor = tg.backgroundColor;
        
        // Пытаемся авторизоваться
        authenticateUser();
    }, []);

    const authenticateUser = async () => {
        try {
            setLoading(true);
            setError(null);
            
            // Получаем initData от Telegram
            const initData = tg.initData;
            
            if (!initData) {
                throw new Error('InitData not available. Please open in Telegram.');
            }
            
            // Отправляем на backend для валидации
            const response = await axios.post(`${API_URL}/auth/telegram`, {
                initData
            });
            
            const { token, user } = response.data;
            
            // Сохраняем токен
            localStorage.setItem('auth_token', token);
            
            // Настраиваем axios для всех последующих запросов
            axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
            
            // Устанавливаем состояние
            setUser(user);
            setAuthenticated(true);
            
        } catch (err) {
            console.error('Auth error:', err);
            setError(err.response?.data?.error || err.message);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="loading" style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '100vh',
                color: tg.themeParams.text_color
            }}>
                <div>Загрузка...</div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="error" style={{
                padding: '20px',
                color: tg.themeParams.text_color
            }}>
                <h2>Ошибка авторизации</h2>
                <p>{error}</p>
                <button onClick={authenticateUser}>
                    Попробовать снова
                </button>
            </div>
        );
    }

    if (!authenticated) {
        return <div>Не авторизован</div>;
    }

    return (
        <div className="app" style={{
            padding: '20px',
            color: tg.themeParams.text_color,
            backgroundColor: tg.themeParams.bg_color
        }}>
            <h1>Привет, {user.first_name}!</h1>
            <p>Telegram ID: {user.telegram_id}</p>
            <p>Username: @{user.username || 'не указан'}</p>
            
            {user.is_premium && (
                <div className="premium-badge">
                    ⭐ Premium пользователь
                </div>
            )}
        </div>
    );
}

export default App;
```

### Создание защищенного API клиента

```javascript
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'https://your-api.com';

// Создаем экземпляр axios
const api = axios.create({
    baseURL: API_URL,
    timeout: 10000,
});

// Добавляем токен к каждому запросу
api.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('auth_token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Обрабатываем ошибки авторизации
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            // Токен недействителен - нужна повторная авторизация
            localStorage.removeItem('auth_token');
            window.location.reload();
        }
        return Promise.reject(error);
    }
);

// API методы
export const authAPI = {
    loginWithTelegram: (initData) => 
        api.post('/auth/telegram', { initData }),
    
    getProfile: () => 
        api.get('/user/profile'),
    
    updateProfile: (data) => 
        api.patch('/user/profile', data),
};

export const dataAPI = {
    getItems: () => 
        api.get('/items'),
    
    createItem: (item) => 
        api.post('/items', item),
    
    updateItem: (id, item) => 
        api.patch(`/items/${id}`, item),
    
    deleteItem: (id) => 
        api.delete(`/items/${id}`),
};

export default api;
```

### React Hook для авторизации

```javascript
import { useState, useEffect, useCallback } from 'react';
import { authAPI } from '../utils/api';

export const useAuth = () => {
    const [tg] = useState(window.Telegram.WebApp);
    const [loading, setLoading] = useState(true);
    const [authenticated, setAuthenticated] = useState(false);
    const [user, setUser] = useState(null);
    const [error, setError] = useState(null);

    const login = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);

            const initData = tg.initData;
            
            if (!initData) {
                throw new Error('Not running in Telegram');
            }

            const response = await authAPI.loginWithTelegram(initData);
            const { token, user } = response.data;

            localStorage.setItem('auth_token', token);
            setUser(user);
            setAuthenticated(true);

        } catch (err) {
            setError(err.response?.data?.error || err.message);
            setAuthenticated(false);
        } finally {
            setLoading(false);
        }
    }, [tg]);

    const logout = useCallback(() => {
        localStorage.removeItem('auth_token');
        setUser(null);
        setAuthenticated(false);
    }, []);

    useEffect(() => {
        login();
    }, [login]);

    return {
        loading,
        authenticated,
        user,
        error,
        login,
        logout,
        tg
    };
};

// Использование в компоненте:
// const { loading, authenticated, user, error, login, tg } = useAuth();
```

---

## ⚙️ Backend реализация

### Полный Express.js сервер

```javascript
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const authMiddleware = require('./middleware/auth');

const app = express();

// Middleware
app.use(cors({
    origin: process.env.FRONTEND_URL,
    credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api', authRoutes);
app.use('/api/user', authMiddleware, userRoutes);

// Health check
app.get('/health', (req, res) => {
    res.json({ status: 'ok' });
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
```

### Auth Middleware для защиты роутов

```javascript
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const authMiddleware = async (req, res, next) => {
    try {
        // Получаем токен из заголовка
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                error: 'No token provided'
            });
        }
        
        const token = authHeader.substring(7);
        
        // Верифицируем токен
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // Загружаем пользователя
        const user = await User.findById(decoded.userId);
        
        if (!user) {
            return res.status(401).json({
                error: 'User not found'
            });
        }
        
        // Добавляем пользователя в request
        req.user = user;
        next();
        
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                error: 'Invalid token'
            });
        }
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                error: 'Token expired'
            });
        }
        res.status(500).json({
            error: 'Internal server error'
        });
    }
};

module.exports = authMiddleware;
```

### Защищенные роуты пользователя

```javascript
const express = require('express');
const router = express.Router();

// Все роуты здесь защищены authMiddleware

// Получить профиль текущего пользователя
router.get('/profile', async (req, res) => {
    try {
        res.json({
            user: {
                id: req.user._id,
                telegram_id: req.user.telegram_id,
                username: req.user.username,
                first_name: req.user.first_name,
                last_name: req.user.last_name,
                is_premium: req.user.is_premium,
                created_at: req.user.created_at
            }
        });
    } catch (error) {
        res.status(500).json({
            error: 'Failed to load profile'
        });
    }
});

// Обновить профиль
router.patch('/profile', async (req, res) => {
    try {
        const { bio, preferences } = req.body;
        
        if (bio) req.user.bio = bio;
        if (preferences) req.user.preferences = preferences;
        
        await req.user.save();
        
        res.json({
            success: true,
            user: req.user
        });
    } catch (error) {
        res.status(500).json({
            error: 'Failed to update profile'
        });
    }
});

// Удалить аккаунт
router.delete('/account', async (req, res) => {
    try {
        await req.user.remove();
        
        res.json({
            success: true,
            message: 'Account deleted'
        });
    } catch (error) {
        res.status(500).json({
            error: 'Failed to delete account'
        });
    }
});

module.exports = router;
```

---

## 🔒 Безопасность

> **🚨 КРИТИЧЕСКИ ВАЖНО:** Соблюдайте эти правила безопасности!

### Чек-лист безопасности

#### ✅ ОБЯЗАТЕЛЬНО делайте:

- Всегда проверяйте `hash` на backend
- Проверяйте `auth_date` (не старше 24 часов)
- Храните `BOT_TOKEN` в переменных окружения
- Используйте HTTPS для всех запросов
- Генерируйте JWT с expiration временем
- Валидируйте JWT на каждом защищенном endpoint
- Используйте rate limiting на auth endpoint
- Логируйте все попытки авторизации

#### ❌ НИКОГДА не делайте:

- Не доверяйте `initDataUnsafe` без проверки
- Не храните `BOT_TOKEN` в frontend коде
- Не пропускайте проверку hash
- Не используйте HTTP (только HTTPS)
- Не игнорируйте проверку `auth_date`
- Не создавайте JWT без expiration
- Не коммитьте секреты в Git

### Защита от атак

| Атака | Защита |
|-------|--------|
| **Подделка initData** | Проверка HMAC-SHA256 hash на backend |
| **Replay attack** | Проверка auth_date (временное окно) |
| **Token theft** | HTTPS, HttpOnly cookies, короткий expiration |
| **Brute force** | Rate limiting, CAPTCHA |
| **SQL Injection** | Prepared statements, ORM |
| **XSS** | Санитизация ввода, CSP headers |

### Пример .env файла

```bash
# Telegram Bot
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# JWT
JWT_SECRET=your-super-secret-jwt-key-change-this
JWT_EXPIRATION=30d

# Database
MONGODB_URI=mongodb://localhost:27017/telegram-app

# Server
PORT=3000
NODE_ENV=production
FRONTEND_URL=https://your-app.com

# Security
RATE_LIMIT_WINDOW=15m
RATE_LIMIT_MAX_REQUESTS=100
```

### Rate Limiting

```javascript
const rateLimit = require('express-rate-limit');

const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 минут
    max: 10, // максимум 10 попыток
    message: {
        error: 'Too many authentication attempts, please try again later'
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// Использование:
// app.use('/api/auth', authLimiter, authRoutes);
```

---

## 💡 Best Practices

### UX/UI
- Используйте темы Telegram
- Адаптируйте под viewport
- Показывайте loading states
- Используйте MainButton
- Поддерживайте свайп назад

### ⚡ Производительность
- Минимизируйте bundle size
- Используйте code splitting
- Кешируйте статику
- Оптимизируйте изображения
- Используйте CDN

### 🔐 Безопасность
- Всегда проверяйте hash
- Используйте HTTPS
- Валидируйте JWT
- Применяйте rate limiting
- Логируйте аномалии

### 📱 Compatibility
- Тестируйте на iOS
- Тестируйте на Android
- Проверяйте Desktop
- Проверяйте Web версию
- Учитывайте разные версии SDK

### Структура проекта

```
telegram-mini-app/
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   ├── hooks/
│   │   │   └── useAuth.js
│   │   ├── utils/
│   │   │   └── api.js
│   │   ├── App.jsx
│   │   └── index.js
│   ├── .env
│   └── package.json
│
├── backend/
│   ├── models/
│   │   └── User.js
│   ├── routes/
│   │   ├── auth.js
│   │   └── user.js
│   ├── middleware/
│   │   ├── auth.js
│   │   └── rateLimit.js
│   ├── utils/
│   │   └── validateInitData.js
│   ├── server.js
│   ├── .env
│   └── package.json
│
└── README.md
```

---

## 🐛 Частые проблемы и решения

### ❌ Проблема: initData пустой

**Причина:** Приложение запущено не в Telegram

**Решение:**
```javascript
if (!window.Telegram?.WebApp?.initData) {
    console.error('Please open this app in Telegram');
    // Показать сообщение пользователю
}
```

### ❌ Проблема: Hash не совпадает

**Причина:** Неправильный BOT_TOKEN или ошибка в алгоритме

**Решение:**
- Проверьте BOT_TOKEN (должен быть от @BotFather)
- Убедитесь что используете правильный алгоритм
- Проверьте что initData передается без изменений

### ❌ Проблема: CORS ошибка

**Причина:** Backend не настроен для принятия запросов

**Решение:**
```javascript
app.use(cors({
    origin: process.env.FRONTEND_URL,
    credentials: true
}));
```

### ❌ Проблема: Приложение не развернуто на весь экран

**Причина:** Не вызван метод expand()

**Решение:**
```javascript
tg.ready();
tg.expand();
```

### ❌ Проблема: Темная тема не применяется

**Причина:** Не используются themeParams

**Решение:**
```javascript
document.body.style.backgroundColor = tg.themeParams.bg_color;
document.body.style.color = tg.themeParams.text_color;
```

---

## 🚀 Готовы начать?

Теперь у вас есть все знания для создания Telegram Mini App с полной аутентификацией!

### Полезные ссылки:

- [Официальная документация](https://core.telegram.org/bots/webapps)
- [Создать бота (@BotFather)](https://t.me/BotFather)
- [Telegram Bot API](https://core.telegram.org/bots/api)

---

**Создано с ❤️ для разработчиков Telegram Mini Apps**