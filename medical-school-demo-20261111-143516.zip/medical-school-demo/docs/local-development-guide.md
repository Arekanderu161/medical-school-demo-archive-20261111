# 🛠️ Local Development Guide for Telegram Mini Apps

**Complete guide for developing and testing Telegram Mini Apps locally using ngrok tunneling**

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Initial Setup](#initial-setup)
4. [Development Workflow](#development-workflow)
5. [Testing in Telegram](#testing-in-telegram)
6. [Troubleshooting](#troubleshooting)
7. [Best Practices](#best-practices)

---

## 🎯 Overview

### The Challenge

Telegram Mini Apps must be served over **HTTPS** and accessible via a **public URL**. This creates a challenge for local development where your application typically runs on `http://localhost:3000`.

### The Solution

We'll use **ngrok** to create a secure tunnel from a public HTTPS URL to your local development server. This allows you to:

- ✅ Develop on your local machine with hot-reload
- ✅ Test in real Telegram environment (iOS/Android/Desktop)
- ✅ Debug with browser DevTools
- ✅ See changes instantly without deployment

### Development Architecture

```mermaid
graph TB
    subgraph "Your Local Machine"
        A[React Dev Server<br/>localhost:3000]
        B[ngrok Process<br/>localhost:4040]
        A <--> B
    end
    
    subgraph "ngrok Cloud"
        C[Public HTTPS URL<br/>https://abc123.ngrok.io]
    end
    
    subgraph "Telegram"
        D[Telegram Bot<br/>@BotFather]
        E[User's Telegram App<br/>iOS/Android/Desktop]
    end
    
    B <--> C
    D --> C
    E --> C
    C --> E
    
    style A fill:#61dafb
    style C fill:#1f8dd6
    style D fill:#229ED9
    style E fill:#229ED9
```

---

## 📦 Prerequisites

### Required Software

| Software | Version | Purpose | Installation |
|----------|---------|---------|--------------|
| **Node.js** | 18+ | Run React dev server | [nodejs.org](https://nodejs.org) |
| **npm/yarn** | Latest | Package manager | Comes with Node.js |
| **ngrok** | 3.x | HTTPS tunneling | [ngrok.com](https://ngrok.com) |
| **Telegram** | Latest | Testing environment | [telegram.org](https://telegram.org) |

### Accounts Required

- ✅ **Telegram Account** - For testing
- ✅ **Telegram Bot** - Created via @BotFather
- ✅ **ngrok Account** - Free tier is sufficient ([Sign up here](https://dashboard.ngrok.com/signup))

---

## 🚀 Initial Setup

### Step 1: Install ngrok

#### Option A: Direct Download (Recommended)

1. Go to [ngrok.com/download](https://ngrok.com/download)
2. Download for your OS (macOS/Windows/Linux)
3. Extract and move to your PATH:

**macOS/Linux:**
```bash
# Download and install
curl -s https://ngrok-agent.s3.amazonaws.com/ngrok.asc | \
  sudo tee /etc/apt/trusted.gpg.d/ngrok.asc >/dev/null && \
  echo "deb https://ngrok-agent.s3.amazonaws.com buster main" | \
  sudo tee /etc/apt/sources.list.d/ngrok.list && \
  sudo apt update && sudo apt install ngrok

# Or using Homebrew on macOS
brew install ngrok/ngrok/ngrok
```

**Windows:**
```powershell
# Using Chocolatey
choco install ngrok

# Or download and add to PATH manually
```

4. Verify installation:
```bash
ngrok version
# Should output: ngrok version 3.x.x
```

#### Option B: NPM Global Install

```bash
npm install -g ngrok
```

### Step 2: Configure ngrok Authentication

1. Sign up at [dashboard.ngrok.com](https://dashboard.ngrok.com/signup)
2. Get your authtoken from [dashboard.ngrok.com/get-started/your-authtoken](https://dashboard.ngrok.com/get-started/your-authtoken)
3. Configure ngrok with your token:

```bash
ngrok config add-authtoken YOUR_AUTH_TOKEN_HERE
```

**Example:**
```bash
ngrok config add-authtoken 2abcDefGHijkLMnopQRstuVWXyz_123ABCdefGHIjkLmNOpQrSTu
```

✅ **Verification:** Run `ngrok config check` to verify configuration

---

### Step 3: Create Telegram Bot

1. **Open Telegram** and search for [@BotFather](https://t.me/BotFather)

2. **Create a new bot:**
```
/newbot
```

3. **Follow the prompts:**
```
BotFather: Alright, a new bot. How are we going to call it?
You: AI Video Generator Bot

BotFather: Good. Now let's choose a username for your bot.
You: ai_video_gen_bot

BotFather: Done! Congratulations on your new bot.
```

4. **Save the Bot Token** (you'll need this):
```
Token: 1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
```

5. **Create a Menu Button** (this will launch your Mini App):
```
/mybots
→ Select your bot
→ Bot Settings
→ Menu Button
→ Edit Menu Button URL
```

**⚠️ Important:** Don't set the URL yet - we'll do this after starting ngrok!

---

## 💻 Development Workflow

### Complete Step-by-Step Development Process

#### Step 1: Start Your Local Development Server

1. **Navigate to your project:**
```bash
cd /path/to/your/telegram-mini-app
```

2. **Install dependencies** (first time only):
```bash
npm install
```

3. **Start the dev server:**
```bash
npm run dev
# or
npm start
```

4. **Verify it's running:**
   - Open browser: `http://localhost:3000`
   - You should see your app (may show errors about Telegram SDK - this is normal)

**Expected output:**
```
VITE v5.0.0  ready in 500 ms

➜  Local:   http://localhost:3000/
➜  Network: use --host to expose
➜  press h + enter to show help
```

> 💡 **Tip:** Keep this terminal window open - you'll see hot-reload updates here

---

#### Step 2: Start ngrok Tunnel

**Open a NEW terminal window** (keep dev server running) and run:

```bash
ngrok http 3000
```

**You should see:**
```
ngrok                                                                    

Session Status                online
Account                       your@email.com (Plan: Free)
Version                       3.5.0
Region                        United States (us)
Latency                       45ms
Web Interface                 http://127.0.0.1:4040
Forwarding                    https://abc123def456.ngrok-free.app -> http://localhost:3000

Connections                   ttl     opn     rt1     rt5     p50     p90
                              0       0       0.00    0.00    0.00    0.00
```

**📝 Important Information to Save:**

| Item | Value | Purpose |
|------|-------|---------|
| **Public URL** | `https://abc123def456.ngrok-free.app` | Your Mini App URL |
| **Web Interface** | `http://127.0.0.1:4040` | Traffic inspector |

> 🔴 **Keep this terminal window open** - closing it will stop the tunnel!

---

#### Step 3: Configure Your Bot with ngrok URL

1. **Copy the ngrok HTTPS URL** from the terminal (e.g., `https://abc123def456.ngrok-free.app`)

2. **Open Telegram** and go to [@BotFather](https://t.me/BotFather)

3. **Set the Menu Button URL:**
```
/mybots
→ Select your bot (e.g., "AI Video Generator Bot")
→ Bot Settings
→ Menu Button
→ Edit Menu Button URL
→ Paste: https://abc123def456.ngrok-free.app
```

4. **Set Menu Button Text:**
```
→ Edit Menu Button Text
→ Type: Open App
```

5. **Done!** Your bot is now configured to open your local app

---

#### Step 4: Test in Telegram

1. **Find your bot** in Telegram search (e.g., `@ai_video_gen_bot`)

2. **Start the bot:**
```
/start
```

3. **Click the "Open App" button** (menu button at bottom)

4. **Your local app should open!** 🎉

**What you should see:**
- Your React app loads inside Telegram
- Telegram theme is applied
- You have access to `window.Telegram.WebApp`
- `initData` is available for authentication

---

#### Step 5: Development Loop

Now you're ready to develop! Here's the workflow:

```mermaid
graph LR
    A[Edit Code] --> B[Save File]
    B --> C[Hot Reload]
    C --> D[Refresh in Telegram]
    D --> E[Test Feature]
    E --> A
    
    style A fill:#61dafb
    style D fill:#229ED9
    style E fill:#10b981
```

1. **Edit your code** in your IDE (VSCode, etc.)
2. **Save the file** - Vite/Webpack will automatically rebuild
3. **Refresh the Mini App** in Telegram (swipe down or reopen)
4. **See your changes instantly!**

**Example development cycle:**

```bash
# Terminal 1: Dev server (running)
VITE v5.0.0  ready in 500 ms
5:23:45 PM [vite] hmr update /src/App.jsx

# Terminal 2: ngrok (running)
HTTP Requests
-------------
GET /                          200 OK
GET /assets/index.js          200 OK
```

---

### Monitoring Traffic with ngrok Web Interface

While developing, you can inspect all HTTP traffic:

1. **Open in browser:** `http://127.0.0.1:4040`

2. **You'll see:**
   - All HTTP requests/responses
   - Request headers (including Telegram initData)
   - Response status codes
   - Request timing
   - Replay requests for debugging

**Useful for:**
- ✅ Debugging API calls
- ✅ Inspecting Telegram initData
- ✅ Checking CORS issues
- ✅ Monitoring performance

---

## 🔧 Environment Configuration

### Setting Up Environment Variables

Your app needs to work in both local and production environments.

#### Frontend (.env)

Create `/frontend/.env`:

```bash
# Development with ngrok
VITE_API_URL=https://your-backend-url.com/api
# or for local backend testing:
# VITE_API_URL=https://another-ngrok-url.ngrok-free.app/api

# Telegram Bot Token (for reference, never use in frontend)
# VITE_BOT_USERNAME=ai_video_gen_bot
```

#### Backend (.env)

Create `/backend/.env`:

```bash
# Telegram Bot Configuration
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-minimum-32-characters-long
JWT_EXPIRATION=30d

# Database
CONVEX_URL=https://your-convex-deployment.convex.cloud
# or for testing:
# MONGODB_URI=mongodb://localhost:27017/telegram-app

# OpenAI API
OPENAI_API_KEY=sk-proj-...your-key...

# Server Configuration
PORT=3001
NODE_ENV=development

# CORS Configuration (allow ngrok URL)
FRONTEND_URL=https://abc123def456.ngrok-free.app

# Rate Limiting
RATE_LIMIT_WINDOW=15m
RATE_LIMIT_MAX_REQUESTS=100
```

---

## 🧪 Testing Scenarios

### Test Checklist for Local Development

Use this checklist every time you make changes:

#### ✅ Authentication Flow
```
□ Open bot in Telegram
□ Click "Open App"
□ Check that app initializes
□ Verify user data appears
□ Check localStorage for token
□ Inspect Network tab for auth request
```

#### ✅ Telegram SDK Integration
```
□ tg.ready() is called
□ tg.expand() works
□ Theme colors are applied
□ MainButton appears if needed
□ BackButton works
□ Viewport is correct size
```

#### ✅ API Connectivity
```
□ API calls succeed
□ Authentication header is sent
□ CORS is working
□ Error handling works
□ Loading states display
```

#### ✅ Multi-Platform Testing
```
□ Test on iPhone (iOS)
□ Test on Android phone
□ Test on Desktop (Windows/Mac)
□ Test on Telegram Web
```

---

## 🐛 Troubleshooting

### Common Issues and Solutions

#### 🔴 Issue: "ERR_NGROK_3200" - Tunnel not found

**Problem:** ngrok session expired or tunnel closed

**Solution:**
```bash
# Stop ngrok (Ctrl+C)
# Start it again
ngrok http 3000

# Update the new URL in @BotFather
```

> 💡 **Pro Tip:** Free ngrok URLs change every restart. Consider upgrading to ngrok paid plan for static URLs.

---

#### 🔴 Issue: "This site can't be reached"

**Problem:** Dev server is not running or ngrok is pointing to wrong port

**Solution:**
```bash
# Check if dev server is running
curl http://localhost:3000

# If not, start it:
npm run dev

# Verify ngrok is pointing to correct port
ngrok http 3000  # Make sure port matches dev server
```

---

#### 🔴 Issue: White screen or "Cannot connect to Telegram"

**Problem:** Telegram SDK script not loaded or app not in Telegram

**Solution:**

1. **Check HTML includes SDK:**
```html
<script src="https://telegram.org/js/telegram-web-app.js"></script>
```

2. **Add development check:**
```javascript
useEffect(() => {
  const tg = window.Telegram?.WebApp;
  
  if (!tg) {
    console.error('Telegram WebApp SDK not loaded');
    return;
  }
  
  if (!tg.initData) {
    console.warn('No initData - not running in Telegram');
    // For development, you can mock data here
  }
  
  tg.ready();
  tg.expand();
}, []);
```

---

#### 🔴 Issue: "Invalid hash" or "401 Unauthorized"

**Problem:** Backend can't validate Telegram initData

**Solutions:**

1. **Check BOT_TOKEN is correct:**
```bash
# In backend .env
BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz  # From @BotFather
```

2. **Verify initData is being sent:**
```javascript
// In frontend
const initData = tg.initData;
console.log('InitData:', initData);

// Should output a long URL-encoded string
```

3. **Check backend validation:**
```javascript
// Add debug logging
console.log('Received initData:', initData);
console.log('Using BOT_TOKEN:', process.env.BOT_TOKEN.substring(0, 10) + '...');
```

4. **Verify timestamp is recent:**
```javascript
// initData contains auth_date - must be < 24 hours old
// If testing for long period, reopen the bot
```

---

#### 🔴 Issue: CORS Error

**Problem:** Backend rejects requests from ngrok URL

**Solution:**

Update backend CORS configuration:

```javascript
// backend/server.js
app.use(cors({
    origin: [
        'https://abc123def456.ngrok-free.app',  // Your ngrok URL
        'http://localhost:3000',                 // Local testing
        process.env.FRONTEND_URL                 // Production URL
    ],
    credentials: true
}));
```

Or use wildcard for development (NOT for production):
```javascript
app.use(cors({
    origin: '*',  // ⚠️ Development only!
    credentials: true
}));
```

---

#### 🔴 Issue: Changes not appearing in Telegram

**Problem:** Telegram is caching the old version

**Solutions:**

1. **Hard refresh in Telegram:**
   - iOS: Pull down to refresh
   - Android: Pull down to refresh
   - Desktop: Close and reopen the bot

2. **Clear Telegram cache:**
   - Go to Settings → Data and Storage → Storage Usage
   - Clear Cache

3. **Verify hot reload is working:**
   - Check dev server terminal for rebuild messages
   - Try changing something obvious (e.g., background color)

---

#### 🔴 Issue: ngrok "Visit Site" warning page

**Problem:** Free ngrok shows an interstitial page

**Solution:**

This is normal for free ngrok accounts. Users see:
```
You are about to visit: abc123.ngrok-free.app
Click "Visit Site" to continue
```

**Options:**
1. **Accept it** - Click "Visit Site" (one-time per session)
2. **Upgrade to paid ngrok** - Removes warning ($8/month)
3. **Use ngrok edge** - Configure skip-browser-warning header:

```javascript
// Add to your API client
headers: {
  'ngrok-skip-browser-warning': 'true'
}
```

---

### Debug Mode Setup

Create a debug panel to help during development:

```javascript
// src/components/DebugPanel.jsx
import { useState } from 'react';

export const DebugPanel = () => {
  const [show, setShow] = useState(false);
  const tg = window.Telegram?.WebApp;
  
  if (process.env.NODE_ENV !== 'development') return null;
  
  return (
    <div style={{
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      background: '#000',
      color: '#0f0',
      padding: '10px',
      fontSize: '10px',
      zIndex: 9999,
      maxHeight: show ? '300px' : '30px',
      overflow: 'auto'
    }}>
      <button onClick={() => setShow(!show)}>
        {show ? '▼' : '▲'} Debug Info
      </button>
      
      {show && (
        <pre style={{ margin: '10px 0' }}>
          Platform: {tg?.platform}
          Version: {tg?.version}
          InitData: {tg?.initData ? '✓ Present' : '✗ Missing'}
          User: {JSON.stringify(tg?.initDataUnsafe?.user, null, 2)}
          Theme: {tg?.colorScheme}
          Viewport: {tg?.viewportHeight}px
        </pre>
      )}
    </div>
  );
};

// Use in App.jsx
import { DebugPanel } from './components/DebugPanel';

function App() {
  return (
    <>
      {/* Your app content */}
      <DebugPanel />
    </>
  );
}
```

---

## 💡 Best Practices for Local Development

### 1. Use ngrok Configuration File

Create `~/.ngrok2/ngrok.yml` for persistent settings:

```yaml
version: "2"
authtoken: YOUR_AUTH_TOKEN

tunnels:
  frontend:
    proto: http
    addr: 3000
    inspect: true
  
  backend:
    proto: http
    addr: 3001
    inspect: true
```

Start multiple tunnels:
```bash
ngrok start frontend backend
```

---

### 2. Create Helper Scripts

Add to `package.json`:

```json
{
  "scripts": {
    "dev": "vite",
    "dev:tunnel": "concurrently \"npm run dev\" \"ngrok http 3000\"",
    "tunnel": "ngrok http 3000",
    "tunnel:inspect": "open http://127.0.0.1:4040"
  },
  "devDependencies": {
    "concurrently": "^8.0.0"
  }
}
```

Start everything at once:
```bash
npm run dev:tunnel
```

---

### 3. Mock Telegram Data for Browser Testing

For testing in regular browser (outside Telegram):

```javascript
// src/utils/mockTelegram.js
export const mockTelegramEnv = () => {
  if (window.Telegram?.WebApp?.initData) {
    return; // Already in Telegram
  }
  
  // Mock for development
  window.Telegram = {
    WebApp: {
      initData: 'query_id=MOCK&user=%7B%22id%22%3A123456789%2C%22first_name%22%3A%22Dev%22%2C%22last_name%22%3A%22User%22%2C%22username%22%3A%22devuser%22%7D&auth_date=1234567890&hash=mock_hash',
      initDataUnsafe: {
        user: {
          id: 123456789,
          first_name: 'Dev',
          last_name: 'User',
          username: 'devuser',
          language_code: 'en'
        }
      },
      version: '6.0',
      platform: 'web',
      colorScheme: 'dark',
      themeParams: {
        bg_color: '#ffffff',
        text_color: '#000000',
        hint_color: '#999999',
        link_color: '#168acd',
        button_color: '#40a7e3',
        button_text_color: '#ffffff'
      },
      isExpanded: true,
      viewportHeight: 800,
      ready: () => console.log('[Mock] Telegram ready'),
      expand: () => console.log('[Mock] Telegram expand'),
      close: () => console.log('[Mock] Telegram close'),
      MainButton: {
        text: '',
        show: () => console.log('[Mock] MainButton show'),
        hide: () => console.log('[Mock] MainButton hide'),
        setText: (text) => console.log('[Mock] MainButton setText:', text),
        onClick: (fn) => console.log('[Mock] MainButton onClick registered')
      }
    }
  };
  
  console.warn('🔶 Running with MOCK Telegram environment');
};

// Use in App.jsx
import { mockTelegramEnv } from './utils/mockTelegram';

if (import.meta.env.DEV) {
  mockTelegramEnv();
}
```

---

### 4. Use Static ngrok URLs (Paid Feature)

Free ngrok URLs change on every restart. Consider upgrading for:

- **Static domain:** `https://your-app.ngrok.app` (never changes)
- **No warning page:** Direct access without "Visit Site" button
- **Custom branding:** Remove ngrok branding

**Setup with static domain:**
```bash
ngrok http 3000 --domain=your-app.ngrok.app
```

Update @BotFather once, never change again! 🎉

---

### 5. Environment Switching

Create multiple environment files:

```
.env.development       # Local development
.env.development.local # Local overrides (gitignored)
.env.production        # Production builds
```

`.env.development`:
```bash
VITE_API_URL=http://localhost:3001/api
VITE_ENV=development
```

`.env.development.local`:
```bash
# Your personal ngrok URL (not committed to git)
VITE_API_URL=https://abc123.ngrok-free.app/api
```

---

## 📋 Quick Reference Commands

### Daily Development Workflow

```bash
# 1. Start dev server (Terminal 1)
cd /path/to/project
npm run dev

# 2. Start ngrok tunnel (Terminal 2)
ngrok http 3000

# 3. Copy ngrok URL and update @BotFather (first time/when changed)

# 4. Open bot in Telegram and start testing!

# 5. When done, stop both:
# Press Ctrl+C in both terminals
```

### ngrok Commands

```bash
# Start tunnel
ngrok http 3000

# Start with specific region
ngrok http 3000 --region us    # us, eu, ap, au, sa, jp, in

# Start with custom subdomain (paid)
ngrok http 3000 --domain=myapp.ngrok.app

# View active tunnels
ngrok ls

# Kill all tunnels
ngrok kill all

# Check configuration
ngrok config check

# View inspector UI
open http://127.0.0.1:4040
```

### Debugging Commands

```bash
# Check if dev server is running
curl http://localhost:3000

# Check if ngrok tunnel works
curl https://your-ngrok-url.ngrok-free.app

# View ngrok logs
ngrok http 3000 --log=stdout

# Test backend validation
curl -X POST http://localhost:3001/api/auth/telegram \
  -H "Content-Type: application/json" \
  -d '{"initData": "..."}'
```

---

## 🎓 Complete Example: First Time Setup

Let's walk through the complete process from scratch:

### Step-by-Step First Run

```bash
# ============================================
# STEP 1: Install and configure ngrok
# ============================================
brew install ngrok/ngrok/ngrok  # macOS
ngrok config add-authtoken YOUR_TOKEN_HERE
ngrok config check  # Verify

# ============================================
# STEP 2: Create and setup project
# ============================================
cd /Users/tyess/dev/vibe-coding-for-club/01
npm install

# ============================================
# STEP 3: Start development server
# ============================================
# Terminal 1:
npm run dev
# Wait for: "Local: http://localhost:3000/"

# ============================================
# STEP 4: Start ngrok tunnel
# ============================================
# Terminal 2:
ngrok http 3000
# Copy the HTTPS URL: https://abc123.ngrok-free.app

# ============================================
# STEP 5: Configure Telegram Bot
# ============================================
# 1. Open Telegram
# 2. Find @BotFather
# 3. Send: /mybots
# 4. Select your bot
# 5. Bot Settings → Menu Button → Edit Menu Button URL
# 6. Paste: https://abc123.ngrok-free.app
# 7. Edit Menu Button Text → Type: "Open App"

# ============================================
# STEP 6: Test!
# ============================================
# 1. Find your bot in Telegram
# 2. Send: /start
# 3. Click "Open App" button
# 4. Your app should open! 🎉

# ============================================
# STEP 7: Develop!
# ============================================
# - Edit files in your IDE
# - Save
# - Refresh in Telegram
# - Repeat!
```

---

## 🚀 Advanced: Production-Like Local Setup

For testing production-like environment locally:

### Using Docker Compose

Create `docker-compose.dev.yml`:

```yaml
version: '3.8'

services:
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    volumes:
      - ./frontend:/app
      - /app/node_modules
    environment:
      - VITE_API_URL=http://backend:3001/api
    command: npm run dev

  backend:
    build: ./backend
    ports:
      - "3001:3001"
    volumes:
      - ./backend:/app
      - /app/node_modules
    environment:
      - BOT_TOKEN=${BOT_TOKEN}
      - JWT_SECRET=${JWT_SECRET}
      - MONGODB_URI=mongodb://mongo:27017/telegram-app
    depends_on:
      - mongo

  mongo:
    image: mongo:7
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db

  ngrok:
    image: ngrok/ngrok:latest
    ports:
      - "4040:4040"
    environment:
      - NGROK_AUTHTOKEN=${NGROK_AUTHTOKEN}
    command: http frontend:3000

volumes:
  mongo_data:
```

Start everything:
```bash
docker-compose -f docker-compose.dev.yml up
```

---

## 📊 Monitoring and Analytics

### Track Development Metrics

Use ngrok's web interface to monitor:

1. **Request volume:** How many requests during testing
2. **Response times:** API performance
3. **Error rates:** Failed requests
4. **User agents:** Which Telegram clients are connecting

Access at: `http://127.0.0.1:4040`

---

## ✅ Pre-Production Checklist

Before deploying to production, test everything locally:

```
□ Authentication flow works
□ All pages load correctly
□ API calls succeed
□ Error handling works
□ Loading states display
□ Telegram theme adapts (light/dark)
□ MainButton functions properly
□ BackButton navigates correctly
□ Works on iOS Telegram
□ Works on Android Telegram
□ Works on Desktop Telegram
□ Works on Telegram Web
□ No console errors
□ No network errors
□ Proper error messages shown to users
□ Environment variables configured
□ Security best practices followed
```

---

## 🎯 Summary

You now have a complete local development environment for Telegram Mini Apps!

**Key Takeaways:**
- ✅ Use **ngrok** to tunnel local server to HTTPS public URL
- ✅ Update @BotFather with ngrok URL
- ✅ Develop normally with hot-reload
- ✅ Test in real Telegram environment
- ✅ Monitor traffic with ngrok inspector
- ✅ Use mock data for browser testing

**Daily Workflow:**
1. Start dev server → 2. Start ngrok → 3. Test in Telegram → 4. Develop & iterate!

---

## 📚 Additional Resources

- [ngrok Documentation](https://ngrok.com/docs)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Telegram WebApps Guide](https://core.telegram.org/bots/webapps)
- [Vite Dev Server](https://vitejs.dev/guide/)

---

**Happy coding! 🚀**

