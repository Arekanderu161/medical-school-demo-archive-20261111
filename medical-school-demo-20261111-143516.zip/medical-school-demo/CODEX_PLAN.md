# CODEX_PLAN.md — веб-школа без Telegram

## Актуальный объём

Демо реализовано. Проверено: 7 модульных тестов, 4 браузерных сценария (Chrome, desktop 1440px и mobile 360px), TypeScript и production-сборка. `npm audit`: 0 известных уязвимостей на момент проверки. Скриншоты просмотрены на обеих ширинах.

Команды: `npm run dev`, `npm test`, `npm run test:e2e`, `npm run typecheck`, `npm run build`.

Отклонения от первоначальных технических вариантов: вместо тестового видео используется явно обозначенный интерактивный макет слайдов; PDF-пример сохраняется из диалога печати браузера. Новые отдельные документы не создавались: инструкции запуска, показа и ограничения собраны в `AGENTS.md` и этом файле.

1. Адаптивная страница одного курса, два предварительных тарифа.
2. Демонстрационное оформление без оплаты и email.
3. Кабинет, уроки, локальный прогресс и печатный пример пособия.
4. Текстовые вопросы на расширенном тарифе и демонстрационный кабинет автора.
5. Обработка ошибок, сброс данных, проверка мобильной раскладки и доступности.
6. Верификация: `npm test`, `npm run typecheck`, `npm run build`.

Готовность демо не означает готовность к продажам. После согласования интерфейса нужны реальные email-сессии, серверные права, идемпотентные платежи с проверкой суммы/валюты, возвраты, защищённое видео, серверная маркировка PDF, ограничение сопровождения, аудит и восстановление резервной копии. Backend и провайдеры не выбраны. На старте не загружать медицинские вложения.

### Проверка вручную

- Каталог → тариф → демо-доступ → урок → прогресс → пособие.
- Самостоятельный тариф не допускает вопрос, расширенный допускает.
- Автор отвечает на конкретный вопрос; ответ виден ученику после переключения режима.
- Прямой hash-переход, перезагрузка, неизвестный урок, ошибка видео, истечение доступа, сброс.
- Клавиатура, фокус, увеличение текста, ширины 360 / 768 / 1440.

## Архив — прежний Telegram-генератор, НЕ реализовывать

Этот документ содержит детальный план реализации **AI Video Generation Telegram Mini App** на базе [`docs/RPD.md`](./docs/RPD.md), [`docs/telegram-mini-app-guide.md`](./docs/telegram-mini-app-guide.md) и [`docs/local-development-guide.md`](./docs/local-development-guide.md).

---

## Фаза 0 — Документация и Инициализация проекта
- [x] Сохранить исходные руководства в `docs/RPD.md`, `docs/telegram-mini-app-guide.md`, `docs/local-development-guide.md`.
- [x] Создать `AGENTS.md` и `CODEX_PLAN.md`.
- [ ] Настроить `package.json`, `tsconfig.json`, `vite.config.ts`, `index.html`, `.env.example`, `.gitignore`.
- [ ] Создать базовые типы и заглушки генерации кода Convex (`convex/_generated/*`), чтобы проект компилировался и проходил `typecheck` даже до первого запуска `npx convex dev`.

## Фаза 1 — Telegram Auth & SDK Integration
- [ ] Реализовать `convex/auth.ts`:
  - HMAC-SHA256 валидация `initData` через Web Crypto API (`crypto.subtle`) с секретом `HMAC-SHA256("WebAppData", BOT_TOKEN)`.
  - Проверка времени `auth_date` (возраст `< 86400` секунд).
  - Выпуск и проверка JWT (`HS256`, срок жизни `30d`).
  - Поддержка безопасного dev-режима для `mockTelegramEnv` при локальной отладке в браузере.
- [ ] Реализовать `convex/http.ts`:
  - HTTP-роутер с `POST /api/auth/telegram` и `OPTIONS /api/auth/telegram` (CORS, `ngrok-skip-browser-warning`).
  - Rate limiting через таблицу `authLogs` (не более 10 попыток за 15 минут).
  - Создание/обновление пользователя и возврат `{ success: true, token, user }`.
- [ ] Реализовать клиентскую интеграцию Telegram SDK:
  - `src/types/telegram.d.ts` — типы `TelegramWebApp`, `MainButton`, `BackButton`, `ThemeParams`.
  - `src/utils/mockTelegram.ts` — `mockTelegramEnv()` с поддержкой всех методов SDK.
  - `src/hooks/useTelegram.ts` — инициализация `ready()`, `expand()`, тема, управление `MainButton` и `BackButton` с корректным `offClick`.
  - `src/hooks/useAuth.ts` — авторизация через `/api/auth/telegram` (с fallback для локального dev-режима без запущенного бэкенда Convex), хранение JWT в `localStorage`.

## Фаза 2 — Convex Schema, Queries, Mutations & OpenAI Integration
- [ ] Описать таблицы `users`, `generations`, `authLogs` и их индексы в `convex/schema.ts`.
- [ ] Реализовать `convex/users.ts`:
  - `upsertUserFromTelegram` (`internalMutation`), `checkAndLogAuthAttempt` (`internalMutation`).
  - `getCurrentUser` (`query`), `updateUser` (`mutation`) с валидацией JWT.
- [ ] Реализовать `convex/generations.ts`:
  - `getGenerations` (`query`) с разрешением `gifUrl` и `videoUrl` через `ctx.storage.getUrl()`.
  - `startGeneration` (`mutation`) и `retryGeneration` (`mutation`) с планированием `internal.ai.generateVideo`.
  - `updateGenerationStatus` (`internalMutation`) и `storeFileIds` (`internalMutation`).
- [ ] Реализовать `convex/ai.ts` (`"use node"`):
  - `generateDetailedPrompt` (`action`) — расширение промпта с помощью OpenAI `gpt-4o-mini` (и детерминированным локальным fallback при отсутствии ключа).
  - `generateVideo` (`internalAction`) — интеграция с OpenAI Sora API (`OPENAI_VIDEO_MODE=live|mock`), поллинг статуса, передача видео в `internal.media.processAndStoreFiles` без превышения 5 MiB лимита аргументов Convex.

## Фаза 3 — Серверная конвертация MP4 → GIF (`convex/media.ts`)
- [ ] Реализовать `convex/media.ts` (`"use node"`):
  - Проверка размера входного видео (отклонение пустых файлов и файлов `> 25 МБ`).
  - Сохранение MP4 в `ctx.storage.store()` → `videoId`.
  - Конвертация MP4 → GIF (`320px`, `8 fps`, зацикленный превью) во временной папке `/tmp` (`os.tmpdir()`) через `ffmpeg-static` (с чистым JS-fallback через `gifenc` для сред без поддержки запуска нативных бинарников).
  - Гарантированная очистка временных файлов в `/tmp` в блоке `finally`.
  - Сохранение GIF в `ctx.storage.store()` → `gifId` и вызов `internal.generations.storeFileIds` со статусом `"completed"`.

## Фаза 4 — UI (4 экрана + нативные компоненты Telegram)
- [ ] `src/components/HistoryChart.tsx` и `src/pages/HistoryPage.tsx` — график активности генераций за последние 7 дней + список последних GIF-превью и статусов.
- [ ] `src/pages/GeneratePage.tsx` — ввод промпта, пресеты стилей, кнопка «AI Help», нативная кнопка `tg.MainButton` («Generate»), отображение real-time прогресса и истории текущей генерации.
- [ ] `src/pages/GalleryPage.tsx` и `src/components/VideoDetailModal.tsx` — сетка готовых GIF-превью, модальное окно с полноэкранным MP4-плеером, копированием промпта, скачиванием, шерингом в Telegram и закрытием через `tg.BackButton`.
- [ ] `src/pages/SettingsPage.tsx` и `src/components/DebugPanel.tsx` — редактирование профиля (`username`, `avatarUrl`) с сохранением в Convex и панель отладки Telegram WebApp SDK для dev-режима.
- [ ] `src/components/BottomNav.tsx` и `src/App.tsx` — нижняя навигация между 4 вкладками, поддержка светлой и тёмной темы Telegram, глобальная обработка состояния авторизации.

## Фаза 5 — Верификация и тесты
- [ ] Написать `tests/auth.test.ts` (HMAC-SHA256 валидация `initData`, проверка `auth_date < 24h`, выпуск и валидация JWT).
- [ ] Написать `tests/media.test.ts` (проверка размеров видео 1–25 МБ, конвертация MP4 → GIF `320px` / `8 fps`, проверка заголовка `GIF89a`, очистка временных файлов в `/tmp`).
- [ ] Выполнить `npm test`, `npm run typecheck`, `npm run build` и убедиться в отсутствии ошибок.
