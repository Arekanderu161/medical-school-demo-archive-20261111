# AGENTS.md — веб-школа «Практика»

## Действующие инструкции: имеют приоритет над архивом ниже

Проект изменён: адаптивное веб-демо одного курса УЗИ щитовидной железы, без Telegram, OpenAI, реальной оплаты, настоящей авторизации и облачного backend.

- Рабочие точки входа: `src/main.tsx`, `src/App.tsx`, `src/school/`.
- `src/components`, `src/pages`, `src/hooks`, `src/utils`, `src/types` и `convex/` относятся к прежней задаче. Они сохранены, но не импортируются и исключены из проверки типов веб-демо.
- Данные курса и демонстрационные условия: `src/school/data.ts`.
- Локальный репозиторий: `src/school/repository.ts`. Клиентские ограничения не являются защитой контента.
- Не собирать реальные email, платежные реквизиты и данные пациентов. Демонстрационные роли и тарифы не переносить в production.
- Не обещать абсолютную защиту от записи. Не использовать спорные материалы Докстарклаб, фиктивные отзывы, квалификации и баллы НМО.
- Исходные `docs/RPD.md`, `docs/telegram-mini-app-guide.md`, `docs/local-development-guide.md` — исторические документы генератора видео, не требования школы.
- Команды: `npm run dev` (localhost:3000), `npm test`, `npm run typecheck`, `npm run build`.
- Требуется Node.js 22 или 24. `npm run test:e2e` проверяет desktop/mobile в установленном Google Chrome; конфигурация: `playwright.config.ts`.
- Как показать: выбрать тариф → «Открыть демо-доступ» → урок → задать вопрос на расширенном тарифе → «Режим автора» → ответить → вернуться в урок.
- Плеер — локальный интерактивный макет слайдов, не видеозапись. Пособие сохраняется в PDF через диалог печати браузера, не через серверную генерацию.
- Демо работает без `.env` и сервисных ключей. Статический хостинг должен раздавать `dist/`; маршруты используют hash.
- Перед рабочим запуском отдельно согласовать права на контент, тарифы, сроки сопровождения, платежи, email-вход, размещение данных, видео и бюджет поддержки.

## Архив прежней задачи — НЕ выполнять для веб-школы

## 1. Обзор проекта
Это Telegram Mini App для генерации AI-видео (OpenAI Sora / GPT API) с реактивным бэкендом на **Convex Cloud** и фронтендом на **React 18 + TypeScript + Vite + Telegram WebApp SDK**.

Обязательные справочные документы в репозитории:
- [`docs/RPD.md`](./docs/RPD.md) — Product Requirements Document (требования к продукту, схема БД, потоки данных).
- [`docs/telegram-mini-app-guide.md`](./docs/telegram-mini-app-guide.md) — полное руководство по архитектуре Telegram Mini Apps, SDK, проверке `initData` и JWT.
- [`docs/local-development-guide.md`](./docs/local-development-guide.md) — настройка локальной разработки через `ngrok`, `@BotFather`, `mockTelegramEnv` и `DebugPanel`.
- [`CODEX_PLAN.md`](./CODEX_PLAN.md) — пошаговый план реализации и чек-лист верификации.

---

## 2. Незыблемые правила безопасности (Security Rules)
1. **Никогда не доверяйте `initDataUnsafe` на бэкенде.** Любая аутентификация обязана проходить валидацию `initData` по алгоритму HMAC-SHA256 с ключом `HMAC-SHA256("WebAppData", BOT_TOKEN)`.
2. **Проверка свежести `auth_date`:** `currentTime - auth_date <= 86400` (не старше 24 часов, защита от replay-атак) и защита от таймстампов из будущего (допуск clock skew ≤ 300 сек).
3. **Защита от перебора (Rate Limiting) и аудит:** Все попытки входа через `POST /api/auth/telegram` логируются в таблицу `authLogs` и ограничиваются по частоте (не более 10 попыток за 15 минут на один идентификатор/IP).
4. **Проверка JWT (30d) во всех публичных функциях Convex:**
   - Публичные `query`, `mutation` и `action` (`getGenerations`, `startGeneration`, `retryGeneration`, `updateUser`, `getCurrentUser`, `generateDetailedPrompt`) принимают `token: v.string()`, проверяют его через `verifyJwt` и извлекают `userId` из верифицированного токена.
   - Никогда не принимайте `userId` напрямую от клиента без сверки с JWT (защита от IDOR).
5. **Изоляция серверных мутаций и экшенов:**
   - `updateGenerationStatus`, `storeFileIds`, `upsertUserFromTelegram`, `checkAndLogAuthAttempt` должны быть строго **`internalMutation`**.
   - `generateVideo` и `processAndStoreFiles` должны быть строго **`internalAction`**.
6. **Секреты только в переменных окружения:** `BOT_TOKEN`, `JWT_SECRET`, `OPENAI_API_KEY` хранятся исключительно на стороне Convex / `.env` и никогда не попадают в клиентский бандл (`VITE_*`).

---

## 3. Архитектурные правила Convex и Медиа-пайплайна
1. **Разделение сред выполнения Convex:**
   - Стандартный рантайм Convex (V8 / WinterCG) используется для `convex/schema.ts`, `convex/auth.ts`, `convex/http.ts`, `convex/users.ts`, `convex/generations.ts`. В этих файлах **нельзя** импортировать Node.js API (`fs`, `os`, `child_process`, `node:crypto`). Для криптографии в `convex/auth.ts` используется стандартный **Web Crypto API (`crypto.subtle`)**.
   - Среда Node.js (`"use node"` в первой строке файла) используется только для `convex/ai.ts` и `convex/media.ts`, которые экспортируют только `action` / `internalAction`.
2. **Обход лимита 5 MiB на аргументы Node.js Actions:**
   - В Convex аргументы, передаваемые в Node.js Action, ограничены 5 MiB, тогда как генерируемые MP4-видео имеют типичный размер **1–25 МБ**.
   - Поэтому `generateVideo` передаёт в `processAndStoreFiles` либо `videoUrl` (временный URL от видео-провайдера), либо `videoStorageId` (уже сохранённый в `ctx.storage` блоб), а `videoBytes` используется только для небольших буферов (< 4 МБ) и модульных тестов.
3. **Серверная конвертация MP4 → GIF (`convex/media.ts`):**
   - Выполняется строго на бэкенде в `processAndStoreFiles` (`"use node"`).
   - Проверяет размер входного MP4 (`1 байт .. 25 МБ`).
   - Сохраняет MP4 в `ctx.storage.store()` (`videoId`).
   - Конвертирует видео в зацикленный GIF-превью (`320px` по ширине, `8 fps`) во временной папке `os.tmpdir()` с обязательным удалением временных файлов в блоке `finally`.
   - Сохраняет GIF в `ctx.storage.store()` (`gifId`) и вызывает `internal.generations.storeFileIds`.

---

## 4. Правила фронтенда и Telegram WebApp SDK
1. **Синхронная загрузка SDK:** `<script src="https://telegram.org/js/telegram-web-app.js"></script>` размещается в `<head>` файла `index.html`.
2. **Инициализация:** При старте приложения вызываются `tg.ready()` и `tg.expand()`, а цвета темы `tg.themeParams` синхронизируются с CSS-переменными `--tg-theme-*`.
3. **Чистка обработчиков нативных кнопок:** При использовании `tg.MainButton.onClick(fn)` и `tg.BackButton.onClick(fn)` внутри `useEffect` обязательно вызывать `offClick(fn)` в cleanup-функции, чтобы избежать накопления дублирующихся колбэков.
4. **Локальная разработка:**
   - В `import.meta.env.DEV` при отсутствии `window.Telegram.WebApp.initData` автоматически активируется `mockTelegramEnv()`.
   - В `vite.config.ts` включён `server.allowedHosts = true` и порт `3000` для бесшовной работы через `ngrok http 3000`.

---

## 5. Команды проверки качества
Перед завершением любой задачи убедитесь, что все три команды выполняются без ошибок:
```bash
npm test
npm run typecheck
npm run build
```
