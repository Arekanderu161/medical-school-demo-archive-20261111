/* eslint-disable */
/**
 * Generated API references for Convex functions.
 */
import { anyApi } from "convex/server";
import type { FilterApi, FunctionReference } from "convex/server";
import type * as auth from "../auth";
import type * as users from "../users";
import type * as generations from "../generations";
import type * as ai from "../ai";
import type * as media from "../media";

declare const fullApi: {
  auth: typeof auth;
  users: typeof users;
  generations: typeof generations;
  ai: typeof ai;
  media: typeof media;
};

export const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
> = anyApi as any;

export const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
> = anyApi as any;
