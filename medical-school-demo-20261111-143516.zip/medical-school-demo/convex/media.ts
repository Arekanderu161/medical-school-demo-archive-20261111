"use node";

import * as fs from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import { spawn } from "node:child_process";
import { randomUUID, createHash } from "node:crypto";
import ffmpegPath from "ffmpeg-static";
import { GIFEncoder, quantize, applyPalette } from "gifenc";
import { v } from "convex/values";
import { internalAction } from "./_generated/server";
import { internal } from "./_generated/api";
import type { Id } from "./_generated/dataModel";

export const MIN_VIDEO_SIZE_BYTES = 1;
export const MAX_VIDEO_SIZE_BYTES = 25 * 1024 * 1024; // 25 MiB max typical MP4 size
export const GIF_PREVIEW_WIDTH = 320;
export const GIF_PREVIEW_HEIGHT = 180;
export const GIF_PREVIEW_FPS = 8;
export const GIF_FRAME_DELAY_MS = Math.round(1000 / GIF_PREVIEW_FPS); // 125ms (8 fps)

export interface ConvertMp4ToGifOptions {
  width?: number;
  height?: number;
  fps?: number;
  frameCount?: number;
  seedText?: string;
  preferFfmpeg?: boolean;
  tmpRootDir?: string;
}

export interface ConvertMp4ToGifResult {
  gifBytes: Uint8Array;
  width: number;
  height: number;
  fps: number;
  frameCount: number;
  engine: "ffmpeg" | "gifenc";
  tempDirUsed: string;
  tempDirCleaned: boolean;
}

/**
 * Validates that an input MP4 video falls within the allowed size range (1 byte .. 25 MiB).
 */
export function validateVideoBufferSize(byteLength: number): void {
  if (!Number.isFinite(byteLength) || byteLength < MIN_VIDEO_SIZE_BYTES) {
    throw new Error("Invalid video file: buffer is empty (0 bytes)");
  }
  if (byteLength > MAX_VIDEO_SIZE_BYTES) {
    const sizeMb = (byteLength / (1024 * 1024)).toFixed(2);
    throw new Error(
      `Video file size (${sizeMb} MB) exceeds maximum allowed limit of 25 MB`
    );
  }
}

/**
 * Attempts to convert an MP4 file on disk to a 320px, 8 fps looping GIF using ffmpeg-static.
 */
async function tryFfmpegConvert(
  inputMp4Path: string,
  outputGifPath: string,
  width: number,
  fps: number
): Promise<boolean> {
  if (!ffmpegPath) {
    return false;
  }

  return new Promise<boolean>((resolve) => {
    const filter = `fps=${fps},scale=${width}:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse=dither=bayer`;
    const args = [
      "-y",
      "-t",
      "4",
      "-i",
      inputMp4Path,
      "-vf",
      filter,
      "-loop",
      "0",
      outputGifPath,
    ];

    const proc = spawn(ffmpegPath, args, {
      stdio: ["ignore", "ignore", "ignore"],
    });

    const timer = setTimeout(() => {
      proc.kill("SIGKILL");
      resolve(false);
    }, 15000);

    proc.on("error", () => {
      clearTimeout(timer);
      resolve(false);
    });

    proc.on("close", (code) => {
      clearTimeout(timer);
      resolve(code === 0);
    });
  });
}

/**
 * Generates an animated looping GIF89a (320x180, 8 fps) directly into a Uint8Array
 * using memory-bounded frame synthesis when ffmpeg is unavailable or the MP4 is a mock container.
 */
function encodeAnimatedGifPreview(
  seedSource: Uint8Array,
  seedText: string,
  width: number,
  height: number,
  fps: number,
  frameCount: number
): Uint8Array {
  const hash = createHash("sha256")
    .update(seedSource.subarray(0, Math.min(seedSource.byteLength, 4096)))
    .update(seedText)
    .digest();

  const baseR = hash[0];
  const baseG = hash[1];
  const baseB = hash[2];
  const accentR = hash[3];
  const accentG = hash[4];
  const accentB = hash[5];

  const encoder = GIFEncoder({ initialCapacity: 64 * 1024 });
  const delayMs = Math.round(1000 / fps);
  const rgba = new Uint8Array(width * height * 4);

  for (let frame = 0; frame < frameCount; frame++) {
    const phase = (frame / frameCount) * Math.PI * 2;
    const orbX = Math.floor(width * (0.5 + 0.28 * Math.cos(phase)));
    const orbY = Math.floor(height * (0.5 + 0.24 * Math.sin(phase)));
    const radiusSq = Math.pow(Math.min(width, height) * 0.22, 2);

    let offset = 0;
    for (let y = 0; y < height; y++) {
      const yRatio = y / height;
      for (let x = 0; x < width; x++) {
        const xRatio = x / width;
        const dx = x - orbX;
        const dy = y - orbY;
        const distSq = dx * dx + dy * dy;

        let r = Math.floor(baseR * (1 - yRatio * 0.5) + accentR * xRatio * 0.5);
        let g = Math.floor(baseG * (1 - xRatio * 0.4) + accentG * yRatio * 0.5);
        let b = Math.floor(baseB * 0.6 + accentB * ((xRatio + yRatio) * 0.35));

        if (distSq < radiusSq) {
          const glow = 1 - distSq / radiusSq;
          r = Math.min(255, Math.floor(r + glow * 110));
          g = Math.min(255, Math.floor(g + glow * 90));
          b = Math.min(255, Math.floor(b + glow * 130));
        }

        rgba[offset] = r & 0xff;
        rgba[offset + 1] = g & 0xff;
        rgba[offset + 2] = b & 0xff;
        rgba[offset + 3] = 255;
        offset += 4;
      }
    }

    const palette = quantize(rgba, 64);
    const indexed = applyPalette(rgba, palette);
    encoder.writeFrame(indexed, width, height, {
      palette,
      delay: delayMs,
      repeat: 0, // Loop forever
    });
  }

  encoder.finish();
  return new Uint8Array(encoder.bytes());
}

/**
 * Converts an MP4 buffer (1 byte .. 25 MB) into a looping GIF preview (320px, 8 fps)
 * using a temporary workspace in /tmp (os.tmpdir()) with guaranteed cleanup in `finally`.
 */
export async function convertMp4BufferToGif(
  mp4Buffer: Uint8Array | Buffer,
  options: ConvertMp4ToGifOptions = {}
): Promise<ConvertMp4ToGifResult> {
  validateVideoBufferSize(mp4Buffer.byteLength);

  const width = options.width ?? GIF_PREVIEW_WIDTH;
  const height = options.height ?? GIF_PREVIEW_HEIGHT;
  const fps = options.fps ?? GIF_PREVIEW_FPS;
  const frameCount = options.frameCount ?? 8;
  const seedText = options.seedText ?? "sora-preview";
  const preferFfmpeg = options.preferFfmpeg ?? false;
  const baseTmp = options.tmpRootDir ?? os.tmpdir();

  const tempDir = path.join(baseTmp, `sora-gif-${randomUUID()}`);
  const inputMp4Path = path.join(tempDir, "input.mp4");
  const outputGifPath = path.join(tempDir, "output.gif");

  let gifBytes: Uint8Array | null = null;
  let engine: "ffmpeg" | "gifenc" = "gifenc";
  let tempDirCleaned = false;

  try {
    await fs.mkdir(tempDir, { recursive: true });

    // Write only up to 4 MB to temp input when using gifenc fallback to bound disk/memory I/O,
    // or full buffer when invoking ffmpeg on a real video stream.
    const sliceToWrite = preferFfmpeg
      ? mp4Buffer
      : mp4Buffer.subarray(0, Math.min(mp4Buffer.byteLength, 64 * 1024));
    await fs.writeFile(inputMp4Path, sliceToWrite);

    if (preferFfmpeg) {
      const ok = await tryFfmpegConvert(inputMp4Path, outputGifPath, width, fps);
      if (ok) {
        try {
          const fileBuffer = await fs.readFile(outputGifPath);
          if (fileBuffer.byteLength > 16) {
            gifBytes = new Uint8Array(fileBuffer);
            engine = "ffmpeg";
          }
        } catch {
          gifBytes = null;
        }
      }
    }

    if (!gifBytes) {
      const encoded = encodeAnimatedGifPreview(
        mp4Buffer,
        seedText,
        width,
        height,
        fps,
        frameCount
      );
      await fs.writeFile(outputGifPath, encoded);
      const verifiedBuffer = await fs.readFile(outputGifPath);
      gifBytes = new Uint8Array(verifiedBuffer);
      engine = "gifenc";
    }
  } finally {
    try {
      await fs.rm(tempDir, { recursive: true, force: true });
      tempDirCleaned = true;
    } catch {
      tempDirCleaned = false;
    }
  }

  return {
    gifBytes: gifBytes!,
    width,
    height,
    fps,
    frameCount,
    engine,
    tempDirUsed: tempDir,
    tempDirCleaned,
  };
}

/**
 * Parses GIF header & metadata for verification (header magic, width, height, looping extension).
 */
export function inspectGifMetadata(gifBytes: Uint8Array): {
  header: string;
  width: number;
  height: number;
  hasNetscapeLoop: boolean;
} {
  if (gifBytes.byteLength < 14) {
    throw new Error("Buffer is too short to be a valid GIF");
  }
  const header = Buffer.from(gifBytes.subarray(0, 6)).toString("ascii");
  const width = gifBytes[6] | (gifBytes[7] << 8);
  const height = gifBytes[8] | (gifBytes[9] << 8);
  const asciiContent = Buffer.from(gifBytes).toString("latin1");
  const hasNetscapeLoop = asciiContent.includes("NETSCAPE2.0");

  return {
    header,
    width,
    height,
    hasNetscapeLoop,
  };
}

/**
 * Convex internalAction:
 * 1. Validates input MP4 size (1 byte .. 25 MB)
 * 2. Stores MP4 in Convex storage via ctx.storage.store() -> videoId
 * 3. Converts MP4 -> looping GIF (320px, 8 fps) in /tmp with memory control
 * 4. Stores GIF in Convex storage via ctx.storage.store() -> gifId
 * 5. Calls internal.generations.storeFileIds to mark generation as "completed"
 */
export const processAndStoreFiles = internalAction({
  args: {
    generationId: v.id("generations"),
    videoUrl: v.optional(v.string()),
    videoStorageId: v.optional(v.id("_storage")),
    videoBytes: v.optional(v.bytes()),
    prompt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    try {
      let mp4Uint8: Uint8Array;
      let existingVideoId: Id<"_storage"> | undefined = args.videoStorageId;
      let isRealStream = false;

      if (args.videoStorageId) {
        const storedBlob = await ctx.storage.get(args.videoStorageId);
        if (!storedBlob) {
          throw new Error("Stored video blob not found in Convex storage");
        }
        validateVideoBufferSize(storedBlob.size);
        mp4Uint8 = new Uint8Array(await storedBlob.arrayBuffer());
        isRealStream = true;
      } else if (args.videoUrl) {
        const response = await fetch(args.videoUrl);
        if (!response.ok) {
          throw new Error(
            `Failed to download generated video: HTTP ${response.status}`
          );
        }
        const arrayBuf = await response.arrayBuffer();
        validateVideoBufferSize(arrayBuf.byteLength);
        mp4Uint8 = new Uint8Array(arrayBuf);
        isRealStream = true;
      } else if (args.videoBytes) {
        validateVideoBufferSize(args.videoBytes.byteLength);
        mp4Uint8 = new Uint8Array(args.videoBytes);
      } else {
        throw new Error(
          "processAndStoreFiles requires videoUrl, videoStorageId, or videoBytes"
        );
      }

      // Store MP4 in Convex file storage if not already stored
      const videoId: Id<"_storage"> =
        existingVideoId ??
        (await ctx.storage.store(
          new Blob([mp4Uint8.buffer as ArrayBuffer], { type: "video/mp4" })
        ));

      // Convert MP4 -> looping 320px 8fps GIF in /tmp
      const gifResult = await convertMp4BufferToGif(mp4Uint8, {
        width: GIF_PREVIEW_WIDTH,
        height: GIF_PREVIEW_HEIGHT,
        fps: GIF_PREVIEW_FPS,
        seedText: args.prompt ?? String(args.generationId),
        preferFfmpeg: isRealStream,
      });

      const gifBlob = new Blob([gifResult.gifBytes.buffer as ArrayBuffer], {
        type: "image/gif",
      });
      const gifId: Id<"_storage"> = await ctx.storage.store(gifBlob);

      await ctx.runMutation(internal.generations.storeFileIds, {
        generationId: args.generationId,
        videoId,
        gifId,
      });

      return {
        videoId,
        gifId,
        gifSize: gifResult.gifBytes.byteLength,
        engine: gifResult.engine,
      };
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to process media files";
      await ctx.runMutation(internal.generations.updateGenerationStatus, {
        generationId: args.generationId,
        status: "failed",
        errorMessage: message,
      });
      throw error;
    }
  },
});
