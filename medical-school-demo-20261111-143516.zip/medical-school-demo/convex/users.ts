import { v } from "convex/values";
import { internalMutation, mutation, query } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { requireAuthPayload } from "./auth";

const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const RATE_LIMIT_MAX_ATTEMPTS = 10;

/**
 * Checks rate limit (10 attempts per 15 minutes) and records the authentication attempt in authLogs.
 */
export const checkAndLogAuthAttempt = internalMutation({
  args: {
    identifier: v.string(),
    telegramId: v.optional(v.string()),
    success: v.boolean(),
    reason: v.optional(v.string()),
    ip: v.optional(v.string()),
    userAgent: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const windowStart = now - RATE_LIMIT_WINDOW_MS;

    const recentLogs = await ctx.db
      .query("authLogs")
      .withIndex("by_identifier_timestamp", (q) =>
        q.eq("identifier", args.identifier).gte("timestamp", windowStart)
      )
      .collect();

    const failedOrTotalCount = recentLogs.length;
    const rateLimited = failedOrTotalCount >= RATE_LIMIT_MAX_ATTEMPTS;

    await ctx.db.insert("authLogs", {
      identifier: args.identifier,
      telegramId: args.telegramId,
      success: rateLimited ? false : args.success,
      reason: rateLimited ? "Rate limit exceeded" : args.reason,
      ip: args.ip,
      userAgent: args.userAgent,
      timestamp: now,
    });

    return {
      allowed: !rateLimited,
      remaining: Math.max(0, RATE_LIMIT_MAX_ATTEMPTS - failedOrTotalCount - 1),
    };
  },
});

/**
 * Internal mutation used by POST /api/auth/telegram to create or update a Telegram user.
 */
export const upsertUserFromTelegram = internalMutation({
  args: {
    telegramId: v.string(),
    username: v.string(),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
    languageCode: v.optional(v.string()),
    isPremium: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const existing = await ctx.db
      .query("users")
      .withIndex("by_telegramId", (q) => q.eq("telegramId", args.telegramId))
      .unique();

    if (!existing) {
      const userId = await ctx.db.insert("users", {
        telegramId: args.telegramId,
        username: args.username,
        firstName: args.firstName,
        lastName: args.lastName,
        avatarUrl: args.avatarUrl,
        languageCode: args.languageCode,
        isPremium: args.isPremium ?? false,
        createdAt: now,
        lastLoginAt: now,
      });
      const created = await ctx.db.get(userId);
      if (!created) {
        throw new Error("Failed to create user record");
      }
      return created;
    }

    await ctx.db.patch(existing._id, {
      firstName: args.firstName ?? existing.firstName,
      lastName: args.lastName ?? existing.lastName,
      languageCode: args.languageCode ?? existing.languageCode,
      isPremium: args.isPremium ?? existing.isPremium,
      avatarUrl: existing.avatarUrl ?? args.avatarUrl,
      lastLoginAt: now,
    });

    const updated = await ctx.db.get(existing._id);
    return updated!;
  },
});

/**
 * PRD-specified createUser mutation (idempotent by telegramId, requires valid JWT).
 */
export const createUser = mutation({
  args: {
    token: v.string(),
    telegramId: v.string(),
    username: v.string(),
    avatarUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const auth = await requireAuthPayload(args.token);
    if (auth.telegramId !== args.telegramId) {
      throw new Error("Forbidden: telegramId mismatch");
    }

    const existing = await ctx.db
      .query("users")
      .withIndex("by_telegramId", (q) => q.eq("telegramId", args.telegramId))
      .unique();

    if (existing) {
      return existing;
    }

    const now = Date.now();
    const id = await ctx.db.insert("users", {
      telegramId: args.telegramId,
      username: args.username.trim() || `user_${args.telegramId}`,
      avatarUrl: args.avatarUrl,
      createdAt: now,
      lastLoginAt: now,
    });
    return await ctx.db.get(id);
  },
});

/**
 * Returns the currently authenticated user profile using the verified JWT.
 */
export const getCurrentUser = query({
  args: {
    token: v.string(),
  },
  handler: async (ctx, args) => {
    const auth = await requireAuthPayload(args.token);
    const byId = await ctx.db.get(auth.userId as Id<"users">);
    if (byId) {
      return byId;
    }
    return await ctx.db
      .query("users")
      .withIndex("by_telegramId", (q) => q.eq("telegramId", auth.telegramId))
      .unique();
  },
});

/**
 * Updates the authenticated user's profile (username and avatarUrl) in Convex.
 */
export const updateUser = mutation({
  args: {
    token: v.string(),
    username: v.string(),
    avatarUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const auth = await requireAuthPayload(args.token);
    const cleanedUsername = args.username.trim();
    if (cleanedUsername.length < 2 || cleanedUsername.length > 48) {
      throw new Error("Username must be between 2 and 48 characters");
    }

    const cleanedAvatar = args.avatarUrl?.trim() || undefined;
    if (
      cleanedAvatar &&
      !cleanedAvatar.startsWith("https://") &&
      !cleanedAvatar.startsWith("data:image/")
    ) {
      throw new Error("Avatar URL must start with https:// or data:image/");
    }

    const user = await ctx.db.get(auth.userId as Id<"users">);
    if (!user) {
      throw new Error("User not found");
    }

    await ctx.db.patch(user._id, {
      username: cleanedUsername,
      avatarUrl: cleanedAvatar,
    });

    return await ctx.db.get(user._id);
  },
});
