import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export const generationStatusValidator = v.union(
  v.literal("pending"),
  v.literal("generating"),
  v.literal("completed"),
  v.literal("failed")
);

export default defineSchema({
  users: defineTable({
    telegramId: v.string(),
    username: v.string(),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    avatarUrl: v.optional(v.string()),
    languageCode: v.optional(v.string()),
    isPremium: v.optional(v.boolean()),
    createdAt: v.number(),
    lastLoginAt: v.optional(v.number()),
  }).index("by_telegramId", ["telegramId"]),

  generations: defineTable({
    userId: v.id("users"),
    prompt: v.string(),
    enhancedPrompt: v.optional(v.string()),
    status: generationStatusValidator,
    videoId: v.optional(v.id("_storage")),
    gifId: v.optional(v.id("_storage")),
    errorMessage: v.optional(v.string()),
    createdAt: v.number(),
    updatedAt: v.optional(v.number()),
  })
    .index("by_userId", ["userId"])
    .index("by_userId_createdAt", ["userId", "createdAt"]),

  authLogs: defineTable({
    identifier: v.string(),
    telegramId: v.optional(v.string()),
    success: v.boolean(),
    reason: v.optional(v.string()),
    ip: v.optional(v.string()),
    userAgent: v.optional(v.string()),
    timestamp: v.number(),
  }).index("by_identifier_timestamp", ["identifier", "timestamp"]),
});
