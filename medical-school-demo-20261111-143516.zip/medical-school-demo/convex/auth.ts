/**
 * Telegram Mini App authentication & JWT utilities.
 * Uses standard Web Crypto API (crypto.subtle) for full compatibility across
 * Convex Default Runtime (httpAction, query, mutation) and Node.js Runtime.
 */

export interface TelegramInitUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
  allows_write_to_pm?: boolean;
  photo_url?: string;
}

export interface ValidateInitDataResult {
  valid: boolean;
  error?: string;
  user?: TelegramInitUser;
  authDate?: number;
  queryId?: string;
}

export interface ValidateInitDataOptions {
  nowSeconds?: number;
  maxAgeSeconds?: number;
  maxFutureSkewSeconds?: number;
  allowDevMock?: boolean;
}

export interface JwtPayload {
  userId: string;
  telegramId: string;
  username?: string;
  iat: number;
  exp: number;
}

export interface VerifyJwtResult {
  valid: boolean;
  error?: string;
  payload?: JwtPayload;
}

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export const DEFAULT_MAX_AGE_SECONDS = 86400; // 24 hours
export const DEFAULT_JWT_EXPIRATION_SECONDS = 30 * 24 * 60 * 60; // 30 days
const DEFAULT_CLOCK_SKEW_SECONDS = 300; // 5 minutes

function bytesToHex(bytes: Uint8Array): string {
  let hex = "";
  for (let i = 0; i < bytes.length; i++) {
    hex += bytes[i].toString(16).padStart(2, "0");
  }
  return hex;
}

function base64UrlEncodeBytes(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlEncodeString(str: string): string {
  return base64UrlEncodeBytes(encoder.encode(str));
}

function base64UrlDecodeToBytes(base64Url: string): Uint8Array {
  const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
  const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function base64UrlDecodeToString(base64Url: string): string {
  return decoder.decode(base64UrlDecodeToBytes(base64Url));
}

/**
 * Constant-time string comparison to prevent timing side-channel attacks.
 */
function timingSafeEqualString(a: string, b: string): boolean {
  const aBytes = encoder.encode(a.toLowerCase());
  const bBytes = encoder.encode(b.toLowerCase());
  if (aBytes.length !== bBytes.length) {
    return false;
  }
  let diff = 0;
  for (let i = 0; i < aBytes.length; i++) {
    diff |= aBytes[i] ^ bBytes[i];
  }
  return diff === 0;
}

async function hmacSha256Raw(
  keyData: Uint8Array | string,
  message: string
): Promise<Uint8Array> {
  const rawKey =
    typeof keyData === "string" ? encoder.encode(keyData) : keyData;
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    rawKey,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const signature = await crypto.subtle.sign(
    "HMAC",
    cryptoKey,
    encoder.encode(message)
  );
  return new Uint8Array(signature);
}

/**
 * Validates Telegram WebApp initData according to official Telegram specification:
 * 1. Parse URLSearchParams
 * 2. Extract `hash` and verify `auth_date` (< 24h)
 * 3. Sort remaining key=value pairs alphabetically and join with '\n'
 * 4. secret_key = HMAC_SHA256(key="WebAppData", data=botToken)
 * 5. calculated_hash = hex(HMAC_SHA256(key=secret_key, data=data_check_string))
 */
export async function validateTelegramInitData(
  initData: string,
  botToken: string,
  options: ValidateInitDataOptions = {}
): Promise<ValidateInitDataResult> {
  if (!initData || typeof initData !== "string" || !initData.trim()) {
    return { valid: false, error: "Missing initData" };
  }
  if (!botToken || typeof botToken !== "string" || !botToken.trim()) {
    return { valid: false, error: "Server BOT_TOKEN is not configured" };
  }

  let params: URLSearchParams;
  try {
    params = new URLSearchParams(initData);
  } catch {
    return { valid: false, error: "Invalid initData format" };
  }

  const receivedHash = params.get("hash");
  const authDateRaw = params.get("auth_date");
  const userRaw = params.get("user");
  const queryId = params.get("query_id") ?? undefined;

  if (!receivedHash || !authDateRaw || !userRaw) {
    return { valid: false, error: "Missing required fields (hash, auth_date, or user)" };
  }

  // Optional dev mock bypass when explicitly enabled for browser debugging outside Telegram
  if (options.allowDevMock && receivedHash === "mock_hash") {
    try {
      const parsedUser = JSON.parse(userRaw) as TelegramInitUser;
      if (!parsedUser || typeof parsedUser.id !== "number") {
        return { valid: false, error: "Invalid user data" };
      }
      return {
        valid: true,
        user: parsedUser,
        authDate: Math.floor(Date.now() / 1000),
        queryId,
      };
    } catch {
      return { valid: false, error: "Invalid user JSON in mock initData" };
    }
  }

  const authDate = Number.parseInt(authDateRaw, 10);
  if (!Number.isFinite(authDate) || authDate <= 0) {
    return { valid: false, error: "Invalid auth_date timestamp" };
  }

  const nowSeconds = options.nowSeconds ?? Math.floor(Date.now() / 1000);
  const maxAgeSeconds = options.maxAgeSeconds ?? DEFAULT_MAX_AGE_SECONDS;
  const maxFutureSkewSeconds =
    options.maxFutureSkewSeconds ?? DEFAULT_CLOCK_SKEW_SECONDS;

  if (nowSeconds - authDate > maxAgeSeconds) {
    return { valid: false, error: "Data is too old (expired auth_date)" };
  }

  if (authDate - nowSeconds > maxFutureSkewSeconds) {
    return { valid: false, error: "Invalid auth_date from the future" };
  }

  const pairs: string[] = [];
  const entries = Array.from(params.entries())
    .filter(([key]) => key !== "hash")
    .sort(([keyA], [keyB]) => (keyA < keyB ? -1 : keyA > keyB ? 1 : 0));

  for (const [key, value] of entries) {
    pairs.push(`${key}=${value}`);
  }
  const dataCheckString = pairs.join("\n");

  const secretKey = await hmacSha256Raw("WebAppData", botToken);
  const calculatedHashBytes = await hmacSha256Raw(secretKey, dataCheckString);
  const calculatedHash = bytesToHex(calculatedHashBytes);

  if (!timingSafeEqualString(calculatedHash, receivedHash)) {
    return { valid: false, error: "Invalid hash" };
  }

  let parsedUser: TelegramInitUser;
  try {
    parsedUser = JSON.parse(userRaw) as TelegramInitUser;
  } catch {
    return { valid: false, error: "Invalid user JSON payload" };
  }

  if (
    !parsedUser ||
    (typeof parsedUser.id !== "number" && typeof parsedUser.id !== "string") ||
    !parsedUser.first_name
  ) {
    return { valid: false, error: "Invalid user object in initData" };
  }

  return {
    valid: true,
    user: {
      id: Number(parsedUser.id),
      first_name: String(parsedUser.first_name),
      last_name: parsedUser.last_name ? String(parsedUser.last_name) : undefined,
      username: parsedUser.username ? String(parsedUser.username) : undefined,
      language_code: parsedUser.language_code
        ? String(parsedUser.language_code)
        : undefined,
      is_premium: Boolean(parsedUser.is_premium),
      allows_write_to_pm: parsedUser.allows_write_to_pm,
      photo_url: parsedUser.photo_url ? String(parsedUser.photo_url) : undefined,
    },
    authDate,
    queryId,
  };
}

/**
 * Helper to create a validly signed Telegram WebApp initData string (used in tests & dev tooling).
 */
export async function createSignedTelegramInitData(
  user: TelegramInitUser,
  botToken: string,
  options: {
    authDate?: number;
    queryId?: string;
    extraParams?: Record<string, string>;
  } = {}
): Promise<string> {
  const authDate = options.authDate ?? Math.floor(Date.now() / 1000);
  const queryId = options.queryId ?? "AAHdF6IQAAAAAN0XohDhrOrc";

  const params = new URLSearchParams();
  params.set("query_id", queryId);
  params.set("user", JSON.stringify(user));
  params.set("auth_date", String(authDate));

  if (options.extraParams) {
    for (const [k, v] of Object.entries(options.extraParams)) {
      params.set(k, v);
    }
  }

  const dataCheckString = Array.from(params.entries())
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");

  const secretKey = await hmacSha256Raw("WebAppData", botToken);
  const hashBytes = await hmacSha256Raw(secretKey, dataCheckString);
  params.set("hash", bytesToHex(hashBytes));

  return params.toString();
}

/**
 * Signs a 30-day JWT (HS256) using Web Crypto API.
 */
export async function signJwt(
  payload: {
    userId: string;
    telegramId: string;
    username?: string;
  },
  secret: string,
  expiresInSeconds: number = DEFAULT_JWT_EXPIRATION_SECONDS,
  nowSeconds?: number
): Promise<string> {
  if (!secret || secret.length < 16) {
    throw new Error("JWT_SECRET must be at least 16 characters long");
  }

  const issuedAt = nowSeconds ?? Math.floor(Date.now() / 1000);
  const fullPayload: JwtPayload = {
    userId: payload.userId,
    telegramId: payload.telegramId,
    username: payload.username,
    iat: issuedAt,
    exp: issuedAt + expiresInSeconds,
  };

  const headerPart = base64UrlEncodeString(
    JSON.stringify({ alg: "HS256", typ: "JWT" })
  );
  const payloadPart = base64UrlEncodeString(JSON.stringify(fullPayload));
  const signingInput = `${headerPart}.${payloadPart}`;
  const signatureBytes = await hmacSha256Raw(secret, signingInput);
  const signaturePart = base64UrlEncodeBytes(signatureBytes);

  return `${signingInput}.${signaturePart}`;
}

/**
 * Verifies an HS256 JWT token and checks expiration.
 */
export async function verifyJwt(
  token: string,
  secret: string,
  nowSeconds?: number
): Promise<VerifyJwtResult> {
  if (!token || typeof token !== "string") {
    return { valid: false, error: "No token provided" };
  }
  if (!secret || typeof secret !== "string") {
    return { valid: false, error: "JWT_SECRET is not configured" };
  }

  const normalized = token.startsWith("Bearer ")
    ? token.slice(7).trim()
    : token.trim();

  const parts = normalized.split(".");
  if (parts.length !== 3) {
    return { valid: false, error: "Invalid token structure" };
  }

  const [headerPart, payloadPart, signaturePart] = parts;
  let header: { alg?: string; typ?: string };
  try {
    header = JSON.parse(base64UrlDecodeToString(headerPart));
  } catch {
    return { valid: false, error: "Invalid token header" };
  }

  if (header.alg !== "HS256") {
    return { valid: false, error: "Unsupported JWT algorithm" };
  }

  const signingInput = `${headerPart}.${payloadPart}`;
  const expectedSigBytes = await hmacSha256Raw(secret, signingInput);
  const expectedSigPart = base64UrlEncodeBytes(expectedSigBytes);

  if (!timingSafeEqualString(expectedSigPart, signaturePart)) {
    return { valid: false, error: "Invalid token signature" };
  }

  let payload: JwtPayload;
  try {
    payload = JSON.parse(base64UrlDecodeToString(payloadPart)) as JwtPayload;
  } catch {
    return { valid: false, error: "Invalid token payload" };
  }

  if (!payload.userId || !payload.telegramId || typeof payload.exp !== "number") {
    return { valid: false, error: "Malformed token claims" };
  }

  const now = nowSeconds ?? Math.floor(Date.now() / 1000);
  if (now >= payload.exp) {
    return { valid: false, error: "Token expired" };
  }

  return { valid: true, payload };
}

export function getEnvJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (secret && secret.length >= 16) {
    return secret;
  }
  if (process.env.NODE_ENV !== "production") {
    return "dev-fallback-jwt-secret-key-minimum-32-chars";
  }
  throw new Error("JWT_SECRET environment variable is required in production");
}

export function getEnvBotToken(): string {
  const token = process.env.BOT_TOKEN;
  if (token && token.trim()) {
    return token.trim();
  }
  if (process.env.NODE_ENV !== "production") {
    return "0000000000:DEV_FALLBACK_TELEGRAM_BOT_TOKEN";
  }
  throw new Error("BOT_TOKEN environment variable is required in production");
}

export async function requireAuthPayload(token: string): Promise<JwtPayload> {
  const secret = getEnvJwtSecret();
  const result = await verifyJwt(token, secret);
  if (!result.valid || !result.payload) {
    throw new Error(`Unauthorized: ${result.error ?? "Invalid token"}`);
  }
  return result.payload;
}
