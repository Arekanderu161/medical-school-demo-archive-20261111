import { v } from "convex/values";
import { internalMutation, mutation, query } from "./_generated/server";
import { internal } from "./_generated/api";
import type { Id } from "./_generated/dataModel";
import { generationStatusValidator } from "./schema";
import { requireAuthPayload } from "./auth";

/**
 * Retrieves the authenticated user's video generations in reverse chronological order,
 * resolving temporary signed URLs for both gifId and videoId from Convex storage.
 */
export const getGenerations = query({
  args: {
    token: v.string(),
  },
  handler: async (ctx, args) => {
    const auth = await requireAuthPayload(args.token);
    const userId = auth.userId as Id<"users">;

    const generations = await ctx.db
      .query("generations")
      .withIndex("by_userId_createdAt", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    return await Promise.all(
      generations.map(async (gen) => {
        const [gifUrl, videoUrl] = await Promise.all([
          gen.gifId ? ctx.storage.getUrl(gen.gifId) : Promise.resolve(null),
          gen.videoId ? ctx.storage.getUrl(gen.videoId) : Promise.resolve(null),
        ]);

        return {
          ...gen,
          gifUrl,
          videoUrl,
        };
      })
    );
  },
});

/**
 * Starts a new AI video generation with status "pending" and schedules the async Sora action.
 */
export const startGeneration = mutation({
  args: {
    token: v.string(),
    prompt: v.string(),
    enhancedPrompt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const auth = await requireAuthPayload(args.token);
    const userId = auth.userId as Id<"users">;

    const trimmedPrompt = args.prompt.trim();
    if (trimmedPrompt.length < 3) {
      throw new Error("Prompt must be at least 3 characters long");
    }
    if (trimmedPrompt.length > 1200) {
      throw new Error("Prompt cannot exceed 1200 characters");
    }

    const now = Date.now();
    const generationId = await ctx.db.insert("generations", {
      userId,
      prompt: trimmedPrompt,
      enhancedPrompt: args.enhancedPrompt?.trim() || undefined,
      status: "pending",
      createdAt: now,
      updatedAt: now,
    });

    await ctx.scheduler.runAfter(0, internal.ai.generateVideo, {
      generationId,
      prompt: trimmedPrompt,
    });

    return generationId;
  },
});

/**
 * Retries a failed video generation owned by the authenticated user.
 */
export const retryGeneration = mutation({
  args: {
    token: v.string(),
    generationId: v.id("generations"),
  },
  handler: async (ctx, args) => {
    const auth = await requireAuthPayload(args.token);
    const userId = auth.userId as Id<"users">;

    const existing = await ctx.db.get(args.generationId);
    if (!existing || existing.userId !== userId) {
      throw new Error("Generation not found or access denied");
    }

    await ctx.db.patch(args.generationId, {
      status: "pending",
      errorMessage: undefined,
      updatedAt: Date.now(),
    });

    await ctx.scheduler.runAfter(0, internal.ai.generateVideo, {
      generationId: args.generationId,
      prompt: existing.prompt,
    });

    return args.generationId;
  },
});

/**
 * Internal mutation to update generation status ("pending" | "generating" | "completed" | "failed").
 */
export const updateGenerationStatus = internalMutation({
  args: {
    generationId: v.id("generations"),
    status: generationStatusValidator,
    errorMessage: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db.get(args.generationId);
    if (!existing) {
      return;
    }

    await ctx.db.patch(args.generationId, {
      status: args.status,
      errorMessage: args.errorMessage,
      updatedAt: Date.now(),
    });
  },
});

/**
 * Internal mutation to store Convex storage IDs for both the full MP4 video and looping GIF preview,
 * transitioning the generation record to "completed".
 */
export const storeFileIds = internalMutation({
  args: {
    generationId: v.id("generations"),
    videoId: v.id("_storage"),
    gifId: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db.get(args.generationId);
    if (!existing) {
      throw new Error(`Generation ${args.generationId} not found`);
    }

    await ctx.db.patch(args.generationId, {
      videoId: args.videoId,
      gifId: args.gifId,
      status: "completed",
      errorMessage: undefined,
      updatedAt: Date.now(),
    });
  },
});
