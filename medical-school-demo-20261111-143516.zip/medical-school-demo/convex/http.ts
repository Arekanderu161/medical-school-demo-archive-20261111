import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";
import { internal } from "./_generated/api";
import {
  getEnvBotToken,
  getEnvJwtSecret,
  signJwt,
  validateTelegramInitData,
} from "./auth";

const http = httpRouter();

function buildCorsHeaders(requestOrigin?: string | null): Record<string, string> {
  const configuredOrigin = process.env.FRONTEND_URL;
  const allowOrigin =
    requestOrigin || configuredOrigin || "*";

  return {
    "Access-Control-Allow-Origin": allowOrigin,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers":
      "Content-Type, Authorization, ngrok-skip-browser-warning",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin",
  };
}

const handleTelegramAuth = httpAction(async (ctx, request) => {
  const origin = request.headers.get("Origin");
  const corsHeaders = buildCorsHeaders(origin);

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("cf-connecting-ip") ||
    "unknown-ip";
  const userAgent = request.headers.get("user-agent") || "unknown-ua";

  let body: { initData?: string };
  try {
    body = (await request.json()) as { initData?: string };
  } catch {
    await ctx.runMutation(internal.users.checkAndLogAuthAttempt, {
      identifier: ip,
      success: false,
      reason: "Invalid JSON body",
      ip,
      userAgent,
    });
    return new Response(
      JSON.stringify({ error: "Invalid request JSON body" }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }

  const initData = body?.initData;
  if (!initData || typeof initData !== "string") {
    const rateCheck = await ctx.runMutation(
      internal.users.checkAndLogAuthAttempt,
      {
        identifier: ip,
        success: false,
        reason: "Missing initData",
        ip,
        userAgent,
      }
    );

    const status = rateCheck.allowed ? 400 : 429;
    return new Response(
      JSON.stringify({
        error: rateCheck.allowed
          ? "initData is required"
          : "Too many authentication attempts, please try again later",
      }),
      {
        status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }

  const botToken = getEnvBotToken();
  const allowDevMock = process.env.ALLOW_DEV_MOCK_AUTH === "true";

  const validation = await validateTelegramInitData(initData, botToken, {
    allowDevMock,
  });

  const telegramId = validation.user ? String(validation.user.id) : undefined;
  const rateIdentifier = telegramId ? `tg:${telegramId}` : `ip:${ip}`;

  const rateCheck = await ctx.runMutation(
    internal.users.checkAndLogAuthAttempt,
    {
      identifier: rateIdentifier,
      telegramId,
      success: validation.valid,
      reason: validation.valid ? "OK" : validation.error,
      ip,
      userAgent,
    }
  );

  if (!rateCheck.allowed) {
    return new Response(
      JSON.stringify({
        error: "Too many authentication attempts, please try again later",
      }),
      {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }

  if (!validation.valid || !validation.user) {
    return new Response(
      JSON.stringify({
        error: "Invalid authentication data",
        details: validation.error,
      }),
      {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }

  const tgUser = validation.user;
  const fallbackUsername =
    tgUser.username ||
    [tgUser.first_name, tgUser.last_name].filter(Boolean).join("_") ||
    `tg_${tgUser.id}`;

  const userDoc = await ctx.runMutation(internal.users.upsertUserFromTelegram, {
    telegramId: String(tgUser.id),
    username: fallbackUsername,
    firstName: tgUser.first_name,
    lastName: tgUser.last_name,
    avatarUrl: tgUser.photo_url,
    languageCode: tgUser.language_code,
    isPremium: tgUser.is_premium ?? false,
  });

  const jwtSecret = getEnvJwtSecret();
  const token = await signJwt(
    {
      userId: String(userDoc._id),
      telegramId: userDoc.telegramId,
      username: userDoc.username,
    },
    jwtSecret
  );

  return new Response(
    JSON.stringify({
      success: true,
      token,
      user: {
        id: userDoc._id,
        telegramId: userDoc.telegramId,
        username: userDoc.username,
        firstName: userDoc.firstName ?? tgUser.first_name,
        lastName: userDoc.lastName ?? tgUser.last_name,
        avatarUrl: userDoc.avatarUrl,
        languageCode: userDoc.languageCode ?? tgUser.language_code,
        isPremium: userDoc.isPremium ?? false,
        createdAt: userDoc.createdAt,
      },
    }),
    {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    }
  );
});

const handleOptions = httpAction(async (_ctx, request) => {
  const origin = request.headers.get("Origin");
  return new Response(null, {
    status: 204,
    headers: buildCorsHeaders(origin),
  });
});

http.route({
  path: "/api/auth/telegram",
  method: "POST",
  handler: handleTelegramAuth,
});

http.route({
  path: "/api/auth/telegram",
  method: "OPTIONS",
  handler: handleOptions,
});

http.route({
  path: "/auth/telegram",
  method: "POST",
  handler: handleTelegramAuth,
});

http.route({
  path: "/auth/telegram",
  method: "OPTIONS",
  handler: handleOptions,
});

export default http;
