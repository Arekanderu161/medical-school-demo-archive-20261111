"use node";

import OpenAI from "openai";
import { createHash } from "node:crypto";
import { v } from "convex/values";
import { action, internalAction } from "./_generated/server";
import { internal } from "./_generated/api";
import { requireAuthPayload } from "./auth";

export type VideoAdapterMode = "live" | "mock";

/**
 * Deterministic cinematic prompt expansion used as a fallback when OPENAI_API_KEY is not set
 * or when running in local mock mode.
 */
export function buildFallbackDetailedPrompt(rawPrompt: string): string {
  const base = rawPrompt.trim().replace(/\.+$/, "");
  return `${base}. Cinematic 4K anamorphic shot, smooth gimbal camera movement, volumetric golden-hour lighting, physically accurate reflections, shallow depth of field (35mm f/1.4 lens), ultra-detailed textures, high dynamic range, 24fps film grain.`;
}

/**
 * Creates a valid synthetic MP4 container buffer (default ~1.2 MB) with ISO Base Media File Format
 * ('ftyp', 'moov', 'mdat' boxes) for mock mode and automated testing.
 */
export function createSyntheticMp4Buffer(
  prompt: string,
  targetSizeBytes: number = 1_200_000
): Uint8Array {
  const size = Math.max(64, targetSizeBytes);
  const buffer = new Uint8Array(size);
  const view = new DataView(buffer.buffer);

  // Box 1: ftyp (24 bytes)
  view.setUint32(0, 24, false);
  buffer.set([0x66, 0x74, 0x79, 0x70], 4); // 'ftyp'
  buffer.set([0x69, 0x73, 0x6f, 0x6d], 8); // 'isom'
  view.setUint32(12, 512, false);
  buffer.set([0x69, 0x73, 0x6f, 0x6d, 0x6d, 0x70, 0x34, 0x32], 16); // 'isommp42'

  // Box 2: moov (16 bytes minimal header)
  view.setUint32(24, 16, false);
  buffer.set([0x6d, 0x6f, 0x6f, 0x76], 28); // 'moov'

  // Box 3: mdat (remaining bytes)
  const mdatOffset = 40;
  const mdatSize = size - mdatOffset;
  view.setUint32(mdatOffset, mdatSize, false);
  buffer.set([0x6d, 0x64, 0x61, 0x74], mdatOffset + 4); // 'mdat'

  const digest = createHash("sha256").update(prompt).digest();
  for (let i = mdatOffset + 8; i < Math.min(size, mdatOffset + 4096); i++) {
    buffer[i] = digest[i % digest.length];
  }

  return buffer;
}

/**
 * Expands a short user idea into a rich, descriptive prompt tailored for OpenAI Sora video generation.
 */
export const generateDetailedPrompt = action({
  args: {
    token: v.string(),
    prompt: v.string(),
  },
  handler: async (_ctx, args) => {
    await requireAuthPayload(args.token);

    const cleanPrompt = args.prompt.trim();
    if (cleanPrompt.length < 2) {
      throw new Error("Please enter at least 2 characters for AI Help");
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey || apiKey.startsWith("sk-proj-your")) {
      return {
        prompt: buildFallbackDetailedPrompt(cleanPrompt),
        source: "fallback" as const,
      };
    }

    try {
      const client = new OpenAI({ apiKey });
      const model = process.env.OPENAI_PROMPT_MODEL || "gpt-4o-mini";

      const completion = await client.chat.completions.create({
        model,
        temperature: 0.7,
        max_tokens: 240,
        messages: [
          {
            role: "system",
            content:
              "You are an expert cinematography prompt engineer for OpenAI Sora. Expand the user's brief idea into a vivid, single-paragraph video generation prompt specifying subject motion, camera angle and movement, lighting, atmosphere, and lens style. Output only the enhanced prompt text without quotes.",
          },
          {
            role: "user",
            content: cleanPrompt,
          },
        ],
      });

      const enhanced = completion.choices[0]?.message?.content?.trim();
      if (!enhanced) {
        return {
          prompt: buildFallbackDetailedPrompt(cleanPrompt),
          source: "fallback" as const,
        };
      }

      return {
        prompt: enhanced,
        source: "openai" as const,
      };
    } catch {
      return {
        prompt: buildFallbackDetailedPrompt(cleanPrompt),
        source: "fallback" as const,
      };
    }
  },
});

async function pollOpenAiSoraVideo(
  apiKey: string,
  prompt: string
): Promise<{ videoUrl?: string; videoBytes?: Uint8Array }> {
  const model = process.env.OPENAI_SORA_MODEL || "sora-2";

  const createRes = await fetch("https://api.openai.com/v1/videos", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      prompt,
      size: "1280x720",
      seconds: "4",
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text();
    throw new Error(`OpenAI Sora API error (${createRes.status}): ${errText}`);
  }

  const job = (await createRes.json()) as {
    id: string;
    status?: string;
    url?: string;
    video_url?: string;
    error?: { message?: string };
  };

  if (job.url || job.video_url) {
    return { videoUrl: job.url ?? job.video_url };
  }

  const maxAttempts = 40;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    await new Promise((r) => setTimeout(r, 3000));

    const pollRes = await fetch(`https://api.openai.com/v1/videos/${job.id}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
    });

    if (!pollRes.ok) {
      throw new Error(`Failed polling Sora video status (${pollRes.status})`);
    }

    const statusData = (await pollRes.json()) as {
      status: string;
      url?: string;
      video_url?: string;
      error?: { message?: string };
    };

    if (statusData.status === "completed" || statusData.status === "succeeded") {
      if (statusData.url || statusData.video_url) {
        return { videoUrl: statusData.url ?? statusData.video_url };
      }

      // Download binary content endpoint if direct URL is not returned in metadata
      const contentRes = await fetch(
        `https://api.openai.com/v1/videos/${job.id}/content`,
        {
          headers: { Authorization: `Bearer ${apiKey}` },
        }
      );
      if (!contentRes.ok) {
        throw new Error(
          `Failed downloading Sora video content (${contentRes.status})`
        );
      }
      const arrayBuf = await contentRes.arrayBuffer();
      return { videoBytes: new Uint8Array(arrayBuf) };
    }

    if (statusData.status === "failed" || statusData.status === "cancelled") {
      throw new Error(
        statusData.error?.message || `Sora video job ${statusData.status}`
      );
    }
  }

  throw new Error("Timed out waiting for OpenAI Sora video generation");
}

/**
 * Asynchronous video generation action scheduled by `startGeneration`.
 * Supports `OPENAI_VIDEO_MODE=live|mock`.
 * Stores or forwards the video to `internal.media.processAndStoreFiles` without exceeding
 * Convex's 5 MiB Node action argument limit.
 */
export const generateVideo = internalAction({
  args: {
    generationId: v.id("generations"),
    prompt: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.runMutation(internal.generations.updateGenerationStatus, {
      generationId: args.generationId,
      status: "generating",
    });

    const mode: VideoAdapterMode =
      process.env.OPENAI_VIDEO_MODE === "live" ? "live" : "mock";
    const apiKey = process.env.OPENAI_API_KEY;

    try {
      if (mode === "live" && apiKey && !apiKey.startsWith("sk-proj-your")) {
        const liveResult = await pollOpenAiSoraVideo(apiKey, args.prompt);

        if (liveResult.videoUrl) {
          await ctx.runAction(internal.media.processAndStoreFiles, {
            generationId: args.generationId,
            videoUrl: liveResult.videoUrl,
            prompt: args.prompt,
          });
          return;
        }

        if (liveResult.videoBytes) {
          // Store in Convex storage first so we never pass >5 MiB in Node action args
          const videoStorageId = await ctx.storage.store(
            new Blob([liveResult.videoBytes.buffer as ArrayBuffer], {
              type: "video/mp4",
            })
          );
          await ctx.runAction(internal.media.processAndStoreFiles, {
            generationId: args.generationId,
            videoStorageId,
            prompt: args.prompt,
          });
          return;
        }
      }

      // Mock adapter mode (or fallback when OPENAI_VIDEO_MODE=mock)
      const mockMp4 = createSyntheticMp4Buffer(args.prompt, 1_250_000);
      const videoStorageId = await ctx.storage.store(
        new Blob([mockMp4.buffer as ArrayBuffer], { type: "video/mp4" })
      );

      await ctx.runAction(internal.media.processAndStoreFiles, {
        generationId: args.generationId,
        videoStorageId,
        prompt: args.prompt,
      });
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : "Video generation failed";
      await ctx.runMutation(internal.generations.updateGenerationStatus, {
        generationId: args.generationId,
        status: "failed",
        errorMessage,
      });
      throw error;
    }
  },
});
